// Moletrix Virtual Chemistry - 16 Full Small Molecule Library
export interface Atom3D {
  id: number;
  element: string;
  symbol: string;
  x: number;
  y: number;
  z: number;
}

export interface Bond3D {
  source: number;
  target: number;
  order: number;
}

export interface SmallMolecule {
  id: string;
  name: string;
  iupacName: string;
  formula: string;
  smiles: string;
  inchiKey: string;
  casNumber: string;
  category: string;
  chemicalFamily?: string;
  functionalGroups?: string[];
  acidBaseProfile?: {
    character: string;
    pKa?: number;
    pKb?: number;
    conjugateSpecies?: string;
  };
  description: string;
  properties: {
    molecularWeight: number;
    logP: number;
    tpsa: number;
    hBondDonors: number;
    hBondAcceptors: number;
    rotatableBonds: number;
    heavyAtomCount: number;
    charge: number;
    solubility: string;
    meltingPoint: string;
    boilingPoint: string;
    density: string;
  };
  lipinskiRuleOf5: {
    passed: boolean;
    violations: number;
    details: string;
    mwPass: boolean;
    logPPass: boolean;
    donorsPass: boolean;
    acceptorsPass: boolean;
  };
  pharmacology: {
    mechanismOfAction: string;
    targetReceptors: string[];
    bioavailability: string;
    halfLife: string;
    metabolism: string;
    clearance: string;
  };
  safetyAndHazards?: {
    ghsSignalWord?: string;
    hazardLevel?: string;
    hazardStatements?: string[];
    precautionaryStatements?: string[];
    ppeChecklist?: string[];
    [key: string]: any;
  };
  synthesisRoute?: {
    name?: string;
    summary?: string;
    steps: Array<{
      stepNumber: number;
      reactionName: string;
      reactants: string[];
      reagents: string[];
      conditions: string;
      mechanism?: string;
      yieldPercent?: number | string;
      yield?: number | string;
      [key: string]: any;
    }>;
    [key: string]: any;
  };
  spectroscopy?: {
    irPeaks?: Array<{ wavenumber: number; intensity: string; bond?: string; assignment?: string; functionalGroup?: string; [key: string]: any }>;
    uvVisMax?: string;
    nmr1H?: any;
    nmr13C?: any;
    [key: string]: any;
  };
  practicalApplications?: any;
  atoms3D: Atom3D[];
  bonds3D: Bond3D[];
}

export const SAMPLE_MOLECULES: SmallMolecule[] = [
  {
    "id": "caffeine",
    "name": "Caffeine",
    "iupacName": "1,3,7-Trimethyl-3,7-dihydro-1H-purine-2,6-dione",
    "formula": "C8H10N4O2",
    "smiles": "CN1C=NC2=C1C(=O)N(C(=O)N2C)C",
    "inchiKey": "RYYVLZVUVIJVGH-UHFFFAOYSA-N",
    "casNumber": "58-08-2",
    "category": "CNS Stimulant / Purine Alkaloid",
    "description": "A methylxanthine class alkaloid that acts as a central nervous system stimulant and reversible competitive antagonist of adenosine receptors, promoting wakefulness and alertness.",
    "properties": {
      "molecularWeight": 194.19,
      "logP": -0.07,
      "tpsa": 58.4,
      "hBondDonors": 0,
      "hBondAcceptors": 6,
      "rotatableBonds": 0,
      "heavyAtomCount": 14,
      "charge": 0,
      "solubility": "21.7 mg/mL in H2O at 25°C",
      "meltingPoint": "235–238 °C (sublimes)",
      "boilingPoint": "178 °C (sublimation point)",
      "density": "1.23 g/cm³"
    },
    "lipinskiRuleOf5": {
      "passed": true,
      "violations": 0,
      "details": "Meets all 4 Lipinski criteria (MW < 500, LogP < 5, H-Donors <= 5, H-Acceptors <= 10). High oral bioavailability expected.",
      "mwPass": true,
      "logPPass": true,
      "donorsPass": true,
      "acceptorsPass": true
    },
    "pharmacology": {
      "mechanismOfAction": "Competitive antagonist of Adenosine A1 and A2A receptors in the brain; inhibits cyclic nucleotide phosphodiesterases (PDEs) at supra-physiological concentrations.",
      "targetReceptors": [
        "Adenosine A1 Receptor",
        "Adenosine A2A Receptor",
        "Ryanodine Receptors (RyR)",
        "PDE-4 (weak)"
      ],
      "bioavailability": "99% (rapidly absorbed via gastrointestinal tract)",
      "halfLife": "3.0 – 7.0 hours in healthy adults",
      "metabolism": "Hepatic cytochrome P450 1A2 (CYP1A2) converts 84% to paraxanthine, 12% to theobromine, and 4% to theophylline.",
      "clearance": "Renal (1-2% unchanged drug in urine)"
    },
    "safetyAndHazards": {
      "hazardLevel": "Moderate",
      "ghsPictograms": [
        "GHS07_Harmful"
      ],
      "ghsSignalWord": "Warning",
      "hazardStatements": [
        "H302: Harmful if swallowed",
        "H319: Causes serious eye irritation"
      ],
      "precautionaryMeasures": [
        "P264: Wash skin thoroughly after handling",
        "P270: Do not eat, drink, or smoke when using this product",
        "P301+P312: IF SWALLOWED: Call a POISON CENTER if unwell"
      ],
      "ppeRequired": [
        "Standard Nitrile Gloves (0.11mm)",
        "ANSI Z87.1 Safety Eyewear",
        "Lab Coat"
      ],
      "disposalProtocol": "Dissolve or mix material with combustible solvent and incinerate in a chemical incinerator equipped with an afterburner and scrubber."
    },
    "synthesisRoute": {
      "summary": "Industrial Traube synthesis starting from dimethylurea and ethyl cyanoacetate via 6-amino-1,3-dimethyluracil followed by nitrosation, reduction, formylation, and methylation.",
      "greenChemistryScore": 78,
      "steps": [
        {
          "stepNumber": 1,
          "reactionName": "Uracil Ring Formation",
          "reactants": [
            "1,3-Dimethylurea",
            "Ethyl cyanoacetate"
          ],
          "reagents": [
            "Sodium ethoxide",
            "Ethanol"
          ],
          "conditions": "Reflux at 80°C for 4 hours",
          "yield": "88%",
          "notes": "Condensation yields 6-amino-1,3-dimethyluracil."
        },
        {
          "stepNumber": 2,
          "reactionName": "Nitrosation & Reduction",
          "reactants": [
            "6-Amino-1,3-dimethyluracil",
            "Sodium nitrite"
          ],
          "reagents": [
            "Acetic acid",
            "Sodium dithionite (Na2S2O4)"
          ],
          "conditions": "10–25°C, exothermic quenching",
          "yield": "92%",
          "notes": "Produces 5,6-diamino-1,3-dimethyluracil intermediate."
        },
        {
          "stepNumber": 3,
          "reactionName": "Imidazole Ring Closure & Methylation",
          "reactants": [
            "5,6-Diamino-1,3-dimethyluracil",
            "Formic acid"
          ],
          "reagents": [
            "Dimethyl sulfate or Methyl iodide",
            "NaOH aq"
          ],
          "conditions": "100°C condensation then 45°C methylation",
          "yield": "85%",
          "notes": "First cyclizes to theophylline, then N7 methylation produces caffeine."
        }
      ]
    },
    "spectroscopy": {
      "irPeaks": [
        {
          "wavenumber": 1695,
          "intensity": "Strong",
          "bond": "C=O",
          "functionalGroup": "Amide carbonyl (C2)"
        },
        {
          "wavenumber": 1655,
          "intensity": "Strong",
          "bond": "C=O",
          "functionalGroup": "Urea carbonyl (C6)"
        },
        {
          "wavenumber": 1548,
          "intensity": "Medium",
          "bond": "C=C / C=N",
          "functionalGroup": "Purine ring skeleton"
        },
        {
          "wavenumber": 2950,
          "intensity": "Medium",
          "bond": "C-H (aliphatic)",
          "functionalGroup": "Methyl groups"
        }
      ],
      "uvVisMax": "273 nm (in water, ε = 9,700 M⁻¹cm⁻¹)",
      "nmr1H": "δ 3.40 (s, 3H, N1-CH3), 3.58 (s, 3H, N3-CH3), 3.99 (s, 3H, N7-CH3), 7.50 (s, 1H, C8-H)",
      "nmr13C": "δ 27.9 (N-Me), 29.8 (N-Me), 33.6 (N-Me), 107.6 (C5), 141.5 (C8), 148.7 (C4), 151.7 (C2=O), 155.5 (C6=O)"
    },
    "practicalApplications": [
      "Beverage formulation (coffee, tea, functional energy blends)",
      "Adjunct in analgesic medications (enhances NSAID pain relief by 40%)",
      "Treatment of apnea of prematurity in neonates",
      "Athletic ergogenic performance enhancer"
    ],
    "atoms3D": [
      {
        "id": 0,
        "element": "N",
        "symbol": "N",
        "x": -1.35,
        "y": -0.42,
        "z": 0.05
      },
      {
        "id": 1,
        "element": "C",
        "symbol": "C",
        "x": -1.22,
        "y": 0.95,
        "z": -0.02
      },
      {
        "id": 2,
        "element": "O",
        "symbol": "O",
        "x": -2.25,
        "y": 1.63,
        "z": -0.08
      },
      {
        "id": 3,
        "element": "N",
        "symbol": "N",
        "x": 0.02,
        "y": 1.54,
        "z": -0.03
      },
      {
        "id": 4,
        "element": "C",
        "symbol": "C",
        "x": 1.18,
        "y": 0.81,
        "z": 0.03
      },
      {
        "id": 5,
        "element": "O",
        "symbol": "O",
        "x": 2.29,
        "y": 1.34,
        "z": 0.03
      },
      {
        "id": 6,
        "element": "C",
        "symbol": "C",
        "x": 1.05,
        "y": -0.63,
        "z": 0.11
      },
      {
        "id": 7,
        "element": "C",
        "symbol": "C",
        "x": -0.21,
        "y": -1.22,
        "z": 0.11
      },
      {
        "id": 8,
        "element": "N",
        "symbol": "N",
        "x": 2.11,
        "y": -1.53,
        "z": 0.18
      },
      {
        "id": 9,
        "element": "C",
        "symbol": "C",
        "x": 1.52,
        "y": -2.67,
        "z": 0.22
      },
      {
        "id": 10,
        "element": "N",
        "symbol": "N",
        "x": 0.13,
        "y": -2.53,
        "z": 0.18
      },
      {
        "id": 11,
        "element": "C",
        "symbol": "C",
        "x": -2.66,
        "y": -1.07,
        "z": 0.06
      },
      {
        "id": 12,
        "element": "C",
        "symbol": "C",
        "x": 0.16,
        "y": 3.01,
        "z": -0.11
      },
      {
        "id": 13,
        "element": "C",
        "symbol": "C",
        "x": 3.56,
        "y": -1.28,
        "z": 0.22
      },
      {
        "id": 14,
        "element": "H",
        "symbol": "H",
        "x": 1.95,
        "y": -3.66,
        "z": 0.28
      },
      {
        "id": 15,
        "element": "H",
        "symbol": "H",
        "x": -3.38,
        "y": -0.38,
        "z": 0.51
      },
      {
        "id": 16,
        "element": "H",
        "symbol": "H",
        "x": -2.62,
        "y": -1.99,
        "z": 0.65
      },
      {
        "id": 17,
        "element": "H",
        "symbol": "H",
        "x": -2.97,
        "y": -1.33,
        "z": -0.96
      },
      {
        "id": 18,
        "element": "H",
        "symbol": "H",
        "x": -0.83,
        "y": 3.46,
        "z": -0.19
      },
      {
        "id": 19,
        "element": "H",
        "symbol": "H",
        "x": 0.72,
        "y": 3.28,
        "z": -1.01
      },
      {
        "id": 20,
        "element": "H",
        "symbol": "H",
        "x": 0.71,
        "y": 3.39,
        "z": 0.76
      },
      {
        "id": 21,
        "element": "H",
        "symbol": "H",
        "x": 3.96,
        "y": -1.74,
        "z": 1.13
      },
      {
        "id": 22,
        "element": "H",
        "symbol": "H",
        "x": 3.73,
        "y": -0.2,
        "z": 0.2
      },
      {
        "id": 23,
        "element": "H",
        "symbol": "H",
        "x": 4.04,
        "y": -1.7,
        "z": -0.66
      }
    ],
    "bonds3D": [
      {
        "source": 0,
        "target": 1,
        "order": 1
      },
      {
        "source": 0,
        "target": 7,
        "order": 1
      },
      {
        "source": 0,
        "target": 11,
        "order": 1
      },
      {
        "source": 1,
        "target": 2,
        "order": 2
      },
      {
        "source": 1,
        "target": 3,
        "order": 1
      },
      {
        "source": 3,
        "target": 4,
        "order": 1
      },
      {
        "source": 3,
        "target": 12,
        "order": 1
      },
      {
        "source": 4,
        "target": 5,
        "order": 2
      },
      {
        "source": 4,
        "target": 6,
        "order": 1
      },
      {
        "source": 6,
        "target": 7,
        "order": 2
      },
      {
        "source": 6,
        "target": 8,
        "order": 1
      },
      {
        "source": 7,
        "target": 10,
        "order": 1
      },
      {
        "source": 8,
        "target": 9,
        "order": 1
      },
      {
        "source": 8,
        "target": 13,
        "order": 1
      },
      {
        "source": 9,
        "target": 10,
        "order": 2
      },
      {
        "source": 9,
        "target": 14,
        "order": 1
      },
      {
        "source": 11,
        "target": 15,
        "order": 1
      },
      {
        "source": 11,
        "target": 16,
        "order": 1
      },
      {
        "source": 11,
        "target": 17,
        "order": 1
      },
      {
        "source": 12,
        "target": 18,
        "order": 1
      },
      {
        "source": 12,
        "target": 19,
        "order": 1
      },
      {
        "source": 12,
        "target": 20,
        "order": 1
      },
      {
        "source": 13,
        "target": 21,
        "order": 1
      },
      {
        "source": 13,
        "target": 22,
        "order": 1
      },
      {
        "source": 13,
        "target": 23,
        "order": 1
      }
    ]
  },
  {
    "id": "aspirin",
    "name": "Aspirin (Acetylsalicylic Acid)",
    "iupacName": "2-Acetyloxybenzoic acid",
    "formula": "C9H8O4",
    "smiles": "CC(=O)Oc1ccccc1C(=O)O",
    "inchiKey": "BSYNRYMUTXBXSQ-UHFFFAOYSA-N",
    "casNumber": "50-78-2",
    "category": "NSAID / Antiplatelet Agent",
    "description": "A salicylic acid ester that irreversibly inhibits cyclooxygenase enzymes (COX-1 and COX-2) via covalent serine acetylation, reducing prostaglandin and thromboxane synthesis.",
    "properties": {
      "molecularWeight": 180.16,
      "logP": 1.19,
      "tpsa": 63.6,
      "hBondDonors": 1,
      "hBondAcceptors": 4,
      "rotatableBonds": 3,
      "heavyAtomCount": 13,
      "charge": 0,
      "solubility": "3.3 mg/mL in H2O at 20°C",
      "meltingPoint": "135 °C",
      "boilingPoint": "140 °C (decomposes)",
      "density": "1.40 g/cm³"
    },
    "lipinskiRuleOf5": {
      "passed": true,
      "violations": 0,
      "details": "Fully compliant with Rule of 5. Excellent gastrointestinal absorption and blood-brain barrier permeability.",
      "mwPass": true,
      "logPPass": true,
      "donorsPass": true,
      "acceptorsPass": true
    },
    "pharmacology": {
      "mechanismOfAction": "Irreversible acetylation of Ser-530 on COX-1 and Ser-516 on COX-2, preventing arachidonic acid docking and suppressing Thromboxane A2 & Prostaglandin E2 synthesis.",
      "targetReceptors": [
        "Cyclooxygenase-1 (COX-1)",
        "Cyclooxygenase-2 (COX-2)",
        "IκB kinase-β (IKKβ)"
      ],
      "bioavailability": "68% (rapid partial de-acetylation in first-pass gut wall and liver)",
      "halfLife": "15 – 20 minutes (aspirin); 2.0 – 3.0 hours (salicylate metabolite)",
      "metabolism": "Rapid ester hydrolysis by plasma and tissue esterases into active salicylic acid, followed by glucuronide and glycine conjugation.",
      "clearance": "Renal clearance pH-dependent (alkaline urine drastically accelerates salicylate excretion)"
    },
    "safetyAndHazards": {
      "hazardLevel": "Moderate",
      "ghsPictograms": [
        "GHS07_Harmful"
      ],
      "ghsSignalWord": "Warning",
      "hazardStatements": [
        "H302: Harmful if swallowed",
        "H315: Causes skin irritation",
        "H319: Causes serious eye irritation"
      ],
      "precautionaryMeasures": [
        "P280: Wear protective gloves and eye protection",
        "P305+P351+P338: IF IN EYES: Rinse cautiously with water for several minutes"
      ],
      "ppeRequired": [
        "Nitrile Gloves",
        "Splash Goggles",
        "Laboratory Coat"
      ],
      "disposalProtocol": "Neutralize with sodium bicarbonate solution before disposal through an authorized chemical waste management contractor."
    },
    "synthesisRoute": {
      "summary": "Acetylation of salicylic acid with acetic anhydride catalyzed by concentrated sulfuric acid or phosphoric acid.",
      "greenChemistryScore": 89,
      "steps": [
        {
          "stepNumber": 1,
          "reactionName": "Kolbe-Schmitt Reaction (Industrial Salicylic Acid)",
          "reactants": [
            "Sodium phenolate",
            "Carbon dioxide (CO2)"
          ],
          "reagents": [
            "Pressure reactor (5-6 atm)"
          ],
          "conditions": "125°C under dry CO2 atmosphere",
          "yield": "90%",
          "notes": "Carboxylation of phenolate yields sodium salicylate, acidified to salicylic acid."
        },
        {
          "stepNumber": 2,
          "reactionName": "Esterification (O-Acetylation)",
          "reactants": [
            "Salicylic acid",
            "Acetic anhydride"
          ],
          "reagents": [
            "Catalytic H2SO4 or H3PO4"
          ],
          "conditions": "50–60°C water bath for 20 minutes",
          "yield": "94%",
          "notes": "Reaction cooled in ice water; aspirin crystallizes cleanly, byproduct is acetic acid."
        }
      ]
    },
    "spectroscopy": {
      "irPeaks": [
        {
          "wavenumber": 1754,
          "intensity": "Strong",
          "bond": "C=O",
          "functionalGroup": "Aryl ester carbonyl"
        },
        {
          "wavenumber": 1685,
          "intensity": "Strong",
          "bond": "C=O",
          "functionalGroup": "Aromatic carboxylic acid carbonyl"
        },
        {
          "wavenumber": 1605,
          "intensity": "Medium",
          "bond": "C=C",
          "functionalGroup": "Aromatic ring stretching"
        },
        {
          "wavenumber": 3000,
          "intensity": "Broad",
          "bond": "O-H",
          "functionalGroup": "Carboxylic acid hydroxyl band"
        }
      ],
      "uvVisMax": "276 nm (in ethanol, ε = 1,100 M⁻¹cm⁻¹)",
      "nmr1H": "δ 2.34 (s, 3H, CH3-CO), 7.14 (dd, 1H, Ar-H), 7.35 (td, 1H, Ar-H), 7.62 (td, 1H, Ar-H), 8.12 (dd, 1H, Ar-H), 11.2 (br s, 1H, COOH)",
      "nmr13C": "δ 21.0 (CH3), 122.3 (C-quat), 123.9 (CH), 126.1 (CH), 132.5 (CH), 134.8 (CH), 151.2 (C-O), 169.6 (C=O ester), 170.1 (C=O acid)"
    },
    "practicalApplications": [
      "Cardiovascular prophylaxis (low-dose 81mg prevents myocardial infarction and ischemic stroke)",
      "Analgesic and antipyretic for acute pain, fever, and migraine",
      "Anti-inflammatory treatment in rheumatoid arthritis and pericarditis"
    ],
    "atoms3D": [
      {
        "id": 0,
        "element": "C",
        "symbol": "C",
        "x": 0,
        "y": 0,
        "z": 0
      },
      {
        "id": 1,
        "element": "C",
        "symbol": "C",
        "x": 1.39,
        "y": 0,
        "z": 0
      },
      {
        "id": 2,
        "element": "C",
        "symbol": "C",
        "x": 2.08,
        "y": 1.21,
        "z": 0
      },
      {
        "id": 3,
        "element": "C",
        "symbol": "C",
        "x": 1.39,
        "y": 2.42,
        "z": 0
      },
      {
        "id": 4,
        "element": "C",
        "symbol": "C",
        "x": 0,
        "y": 2.42,
        "z": 0
      },
      {
        "id": 5,
        "element": "C",
        "symbol": "C",
        "x": -0.69,
        "y": 1.21,
        "z": 0
      },
      {
        "id": 6,
        "element": "C",
        "symbol": "C",
        "x": 2.14,
        "y": -1.29,
        "z": 0
      },
      {
        "id": 7,
        "element": "O",
        "symbol": "O",
        "x": 1.58,
        "y": -2.37,
        "z": 0
      },
      {
        "id": 8,
        "element": "O",
        "symbol": "O",
        "x": 3.49,
        "y": -1.18,
        "z": 0
      },
      {
        "id": 9,
        "element": "O",
        "symbol": "O",
        "x": 3.46,
        "y": 1.28,
        "z": 0
      },
      {
        "id": 10,
        "element": "C",
        "symbol": "C",
        "x": 4.22,
        "y": 0.16,
        "z": 0
      },
      {
        "id": 11,
        "element": "O",
        "symbol": "O",
        "x": 3.79,
        "y": -0.98,
        "z": 0
      },
      {
        "id": 12,
        "element": "C",
        "symbol": "C",
        "x": 5.71,
        "y": 0.42,
        "z": 0
      },
      {
        "id": 13,
        "element": "H",
        "symbol": "H",
        "x": -0.54,
        "y": -0.94,
        "z": 0
      },
      {
        "id": 14,
        "element": "H",
        "symbol": "H",
        "x": 1.93,
        "y": 3.36,
        "z": 0
      },
      {
        "id": 15,
        "element": "H",
        "symbol": "H",
        "x": -0.54,
        "y": 3.36,
        "z": 0
      },
      {
        "id": 16,
        "element": "H",
        "symbol": "H",
        "x": -1.78,
        "y": 1.21,
        "z": 0
      },
      {
        "id": 17,
        "element": "H",
        "symbol": "H",
        "x": 3.91,
        "y": -2.06,
        "z": 0
      },
      {
        "id": 18,
        "element": "H",
        "symbol": "H",
        "x": 6.22,
        "y": -0.54,
        "z": 0
      },
      {
        "id": 19,
        "element": "H",
        "symbol": "H",
        "x": 5.99,
        "y": 0.99,
        "z": 0.89
      },
      {
        "id": 20,
        "element": "H",
        "symbol": "H",
        "x": 5.99,
        "y": 0.99,
        "z": -0.89
      }
    ],
    "bonds3D": [
      {
        "source": 0,
        "target": 1,
        "order": 2
      },
      {
        "source": 1,
        "target": 2,
        "order": 1
      },
      {
        "source": 2,
        "target": 3,
        "order": 2
      },
      {
        "source": 3,
        "target": 4,
        "order": 1
      },
      {
        "source": 4,
        "target": 5,
        "order": 2
      },
      {
        "source": 5,
        "target": 0,
        "order": 1
      },
      {
        "source": 1,
        "target": 6,
        "order": 1
      },
      {
        "source": 6,
        "target": 7,
        "order": 2
      },
      {
        "source": 6,
        "target": 8,
        "order": 1
      },
      {
        "source": 8,
        "target": 17,
        "order": 1
      },
      {
        "source": 2,
        "target": 9,
        "order": 1
      },
      {
        "source": 9,
        "target": 10,
        "order": 1
      },
      {
        "source": 10,
        "target": 11,
        "order": 2
      },
      {
        "source": 10,
        "target": 12,
        "order": 1
      },
      {
        "source": 0,
        "target": 13,
        "order": 1
      },
      {
        "source": 3,
        "target": 14,
        "order": 1
      },
      {
        "source": 4,
        "target": 15,
        "order": 1
      },
      {
        "source": 5,
        "target": 16,
        "order": 1
      },
      {
        "source": 12,
        "target": 18,
        "order": 1
      },
      {
        "source": 12,
        "target": 19,
        "order": 1
      },
      {
        "source": 12,
        "target": 20,
        "order": 1
      }
    ]
  },
  {
    "id": "dopamine",
    "name": "Dopamine",
    "iupacName": "4-(2-Aminoethyl)benzene-1,2-diol",
    "formula": "C8H11NO2",
    "smiles": "C1=CC(=C(C=C1CCN)O)O",
    "inchiKey": "VYFYYTLLBUBZZN-UHFFFAOYSA-N",
    "casNumber": "51-61-6",
    "category": "Catecholamine / Neurotransmitter",
    "description": "An endogenous catecholamine acting as a vital neurohormone and neurotransmitter that regulates reward pathways, voluntary motor control, motivation, executive function, and systemic cardiovascular vascular tone.",
    "properties": {
      "molecularWeight": 153.18,
      "logP": -0.03,
      "tpsa": 66.5,
      "hBondDonors": 3,
      "hBondAcceptors": 3,
      "rotatableBonds": 2,
      "heavyAtomCount": 11,
      "charge": 0,
      "solubility": "600 mg/mL in H2O at 20°C",
      "meltingPoint": "128 °C",
      "boilingPoint": "337.7 °C",
      "density": "1.26 g/cm³"
    },
    "lipinskiRuleOf5": {
      "passed": true,
      "violations": 0,
      "details": "Meets all 4 Lipinski criteria. Note: High polarity prevents crossing blood-brain barrier via passive diffusion (requires L-DOPA precursor).",
      "mwPass": true,
      "logPPass": true,
      "donorsPass": true,
      "acceptorsPass": true
    },
    "pharmacology": {
      "mechanismOfAction": "Agonist at D1-like (D1, D5: Gs-coupled, increases cAMP) and D2-like (D2, D3, D4: Gi-coupled, decreases cAMP) G-protein coupled receptors.",
      "targetReceptors": [
        "Dopamine D1 Receptor",
        "Dopamine D2 Receptor",
        "Dopamine D3 Receptor",
        "α1 and β1 Adrenoceptors (high dose)"
      ],
      "bioavailability": "< 2% oral (due to gastrointestinal and hepatic MAO/COMT rapid breakdown; delivered IV in intensive care)",
      "halfLife": "2 minutes in human plasma",
      "metabolism": "Rapid degradation via monoamine oxidase (MAO-A/B) and catechol-O-methyltransferase (COMT) to homovanillic acid (HVA).",
      "clearance": "Urinary excretion of HVA and conjugated metabolites (80% in 24 hours)"
    },
    "safetyAndHazards": {
      "hazardLevel": "Moderate",
      "ghsPictograms": [
        "GHS07_Harmful"
      ],
      "ghsSignalWord": "Warning",
      "hazardStatements": [
        "H302: Harmful if swallowed",
        "H315: Causes skin irritation",
        "H319: Causes serious eye irritation"
      ],
      "precautionaryMeasures": [
        "P261: Avoid breathing dust/fume/gas",
        "P305+P351+P338: IF IN EYES: Rinse cautiously with water"
      ],
      "ppeRequired": [
        "Nitrile Gloves",
        "Safety Glasses",
        "Fume Hood when handling powdered form"
      ],
      "disposalProtocol": "Aqueous waste disposal via chemical oxidation or authorized bio-hazardous disposal."
    },
    "synthesisRoute": {
      "summary": "Biosynthetically generated from L-tyrosine via L-DOPA decarboxylation. Chemically prepared by condensation of 3,4-dimethoxybenzaldehyde with nitromethane, reduction, and demethylation.",
      "greenChemistryScore": 82,
      "steps": [
        {
          "stepNumber": 1,
          "reactionName": "Henry Condensation",
          "reactants": [
            "3,4-Dimethoxybenzaldehyde (Veratraldehyde)",
            "Nitromethane"
          ],
          "reagents": [
            "Ammonium acetate catalyst"
          ],
          "conditions": "Reflux in glacial acetic acid for 2 hours",
          "yield": "88%",
          "notes": "Yields 3,4-dimethoxy-β-nitrostyrene yellow needles."
        },
        {
          "stepNumber": 2,
          "reactionName": "Catalytic Hydrogenation / Hydride Reduction",
          "reactants": [
            "3,4-Dimethoxy-β-nitrostyrene"
          ],
          "reagents": [
            "Lithium aluminium hydride (LiAlH4) or H2 / Pd-C"
          ],
          "conditions": "Anhydrous THF, room temperature",
          "yield": "84%",
          "notes": "Concurrently reduces nitro and alkene to form homoveratrylamine."
        },
        {
          "stepNumber": 3,
          "reactionName": "Ether Cleavage (Demethylation)",
          "reactants": [
            "Homoveratrylamine"
          ],
          "reagents": [
            "48% Hydrobromic acid (HBr) or Boron tribromide (BBr3)"
          ],
          "conditions": "Reflux at 120°C for 3 hours under inert gas",
          "yield": "91%",
          "notes": "Cleaves both methyl aryl ethers to liberate catechol hydroxyls, crystallizing as dopamine hydrochloride."
        }
      ]
    },
    "spectroscopy": {
      "irPeaks": [
        {
          "wavenumber": 3340,
          "intensity": "Medium",
          "bond": "N-H",
          "functionalGroup": "Primary amine stretching"
        },
        {
          "wavenumber": 3200,
          "intensity": "Broad",
          "bond": "O-H",
          "functionalGroup": "Phenolic hydroxyls"
        },
        {
          "wavenumber": 1602,
          "intensity": "Medium",
          "bond": "C=C",
          "functionalGroup": "Aromatic quadrant stretch"
        },
        {
          "wavenumber": 1285,
          "intensity": "Strong",
          "bond": "C-O",
          "functionalGroup": "Phenolic C-O bond"
        }
      ],
      "uvVisMax": "280 nm (in aqueous buffer, ε = 2,680 M⁻¹cm⁻¹)",
      "nmr1H": "δ 2.75 (t, 2H, Ar-CH2), 2.98 (t, 2H, CH2-N), 6.55 (dd, 1H, Ar-H5), 6.67 (d, 1H, Ar-H2), 6.74 (d, 1H, Ar-H6), 8.8 (br s, 2H, Ar-OH)",
      "nmr13C": "δ 33.2 (CH2), 41.5 (CH2-NH2), 116.1 (C2), 116.7 (C5), 120.4 (C6), 130.1 (C1), 144.1 (C4), 145.5 (C3)"
    },
    "practicalApplications": [
      "Vasopressor in cardiogenic and septic shock refractory to fluid resuscitation",
      "Neurochemical research in Parkinsonian dopamine deficiency models",
      "Neurobiology of reward reinforcement, addiction, and schizophrenia"
    ],
    "atoms3D": [
      {
        "id": 0,
        "element": "C",
        "symbol": "C",
        "x": -1.2,
        "y": 0,
        "z": 0
      },
      {
        "id": 1,
        "element": "C",
        "symbol": "C",
        "x": -0.5,
        "y": 1.2,
        "z": 0
      },
      {
        "id": 2,
        "element": "C",
        "symbol": "C",
        "x": 0.9,
        "y": 1.2,
        "z": 0
      },
      {
        "id": 3,
        "element": "C",
        "symbol": "C",
        "x": 1.6,
        "y": 0,
        "z": 0
      },
      {
        "id": 4,
        "element": "C",
        "symbol": "C",
        "x": 0.9,
        "y": -1.2,
        "z": 0
      },
      {
        "id": 5,
        "element": "C",
        "symbol": "C",
        "x": -0.5,
        "y": -1.2,
        "z": 0
      },
      {
        "id": 6,
        "element": "O",
        "symbol": "O",
        "x": -1.2,
        "y": 2.38,
        "z": 0
      },
      {
        "id": 7,
        "element": "O",
        "symbol": "O",
        "x": 1.55,
        "y": 2.38,
        "z": 0
      },
      {
        "id": 8,
        "element": "C",
        "symbol": "C",
        "x": 3.12,
        "y": 0,
        "z": 0
      },
      {
        "id": 9,
        "element": "C",
        "symbol": "C",
        "x": 3.82,
        "y": -1.35,
        "z": 0.1
      },
      {
        "id": 10,
        "element": "N",
        "symbol": "N",
        "x": 5.27,
        "y": -1.25,
        "z": 0.1
      },
      {
        "id": 11,
        "element": "H",
        "symbol": "H",
        "x": -2.28,
        "y": 0,
        "z": 0
      },
      {
        "id": 12,
        "element": "H",
        "symbol": "H",
        "x": 1.44,
        "y": -2.14,
        "z": 0
      },
      {
        "id": 13,
        "element": "H",
        "symbol": "H",
        "x": -1.04,
        "y": -2.14,
        "z": 0
      },
      {
        "id": 14,
        "element": "H",
        "symbol": "H",
        "x": -0.65,
        "y": 3.18,
        "z": 0
      },
      {
        "id": 15,
        "element": "H",
        "symbol": "H",
        "x": 2.5,
        "y": 2.3,
        "z": 0
      },
      {
        "id": 16,
        "element": "H",
        "symbol": "H",
        "x": 3.48,
        "y": 0.55,
        "z": 0.88
      },
      {
        "id": 17,
        "element": "H",
        "symbol": "H",
        "x": 3.48,
        "y": 0.55,
        "z": -0.88
      },
      {
        "id": 18,
        "element": "H",
        "symbol": "H",
        "x": 3.46,
        "y": -1.9,
        "z": -0.78
      },
      {
        "id": 19,
        "element": "H",
        "symbol": "H",
        "x": 3.46,
        "y": -1.9,
        "z": 0.98
      },
      {
        "id": 20,
        "element": "H",
        "symbol": "H",
        "x": 5.68,
        "y": -2.17,
        "z": 0.18
      },
      {
        "id": 21,
        "element": "H",
        "symbol": "H",
        "x": 5.62,
        "y": -0.75,
        "z": -0.69
      }
    ],
    "bonds3D": [
      {
        "source": 0,
        "target": 1,
        "order": 2
      },
      {
        "source": 1,
        "target": 2,
        "order": 1
      },
      {
        "source": 2,
        "target": 3,
        "order": 2
      },
      {
        "source": 3,
        "target": 4,
        "order": 1
      },
      {
        "source": 4,
        "target": 5,
        "order": 2
      },
      {
        "source": 5,
        "target": 0,
        "order": 1
      },
      {
        "source": 1,
        "target": 6,
        "order": 1
      },
      {
        "source": 6,
        "target": 14,
        "order": 1
      },
      {
        "source": 2,
        "target": 7,
        "order": 1
      },
      {
        "source": 7,
        "target": 15,
        "order": 1
      },
      {
        "source": 3,
        "target": 8,
        "order": 1
      },
      {
        "source": 8,
        "target": 9,
        "order": 1
      },
      {
        "source": 9,
        "target": 10,
        "order": 1
      },
      {
        "source": 0,
        "target": 11,
        "order": 1
      },
      {
        "source": 4,
        "target": 12,
        "order": 1
      },
      {
        "source": 5,
        "target": 13,
        "order": 1
      },
      {
        "source": 8,
        "target": 16,
        "order": 1
      },
      {
        "source": 8,
        "target": 17,
        "order": 1
      },
      {
        "source": 9,
        "target": 18,
        "order": 1
      },
      {
        "source": 9,
        "target": 19,
        "order": 1
      },
      {
        "source": 10,
        "target": 20,
        "order": 1
      },
      {
        "source": 10,
        "target": 21,
        "order": 1
      }
    ]
  },
  {
    "id": "penicillin_g",
    "name": "Penicillin G (Benzylpenicillin)",
    "iupacName": "(2S,5R,6R)-3,3-Dimethyl-7-oxo-6-[(2-phenylacetyl)amino]-4-thia-1-azabicyclo[3.2.0]heptane-2-carboxylic acid",
    "formula": "C16H18N2O4S",
    "smiles": "CC1(C(N2C(C1S2)C(=O)NC(=O)CC3=CC=CC=C3)C(=O)O)C",
    "inchiKey": "ZBDYXZWAIZXEAD-UHFFFAOYSA-N",
    "casNumber": "61-33-6",
    "category": "β-Lactam Antibiotic",
    "description": "Gold-standard narrow-spectrum β-lactam antibiotic derived from Penicillium chrysogenum fungi that blocks bacterial cell wall peptidoglycan cross-linking by acylating transpeptidase enzymes.",
    "properties": {
      "molecularWeight": 334.39,
      "logP": 1.83,
      "tpsa": 98.4,
      "hBondDonors": 2,
      "hBondAcceptors": 5,
      "rotatableBonds": 4,
      "heavyAtomCount": 23,
      "charge": 0,
      "solubility": "0.21 mg/mL in H2O at 25°C (free acid); soluble as sodium/potassium salt",
      "meltingPoint": "214–217 °C (decomposes)",
      "boilingPoint": "663 °C (extrapolated)",
      "density": "1.41 g/cm³"
    },
    "lipinskiRuleOf5": {
      "passed": true,
      "violations": 0,
      "details": "Conforms to Lipinski Rule of 5: MW 334.4 < 500, LogP 1.83 < 5, Donors 2 < 5, Acceptors 5 < 10.",
      "mwPass": true,
      "logPPass": true,
      "donorsPass": true,
      "acceptorsPass": true
    },
    "pharmacology": {
      "mechanismOfAction": "Mimics D-Ala-D-Ala terminus of bacterial peptidoglycan precursor, undergoing irreversible nucleophilic attack by active site serine in Penicillin-Binding Proteins (PBPs), inhibiting cell wall biosynthesis and causing osmotic lysis.",
      "targetReceptors": [
        "Penicillin-Binding Protein 1A/1B (PBP1)",
        "PBP2",
        "PBP3"
      ],
      "bioavailability": "Poor oral (destroyed by gastric acid pH < 2); administered parenterally as IV or IM",
      "halfLife": "30 – 45 minutes",
      "metabolism": "Minimal hepatic (< 20%), predominantly hydrolytic ring opening by bacterial β-lactamases",
      "clearance": "Rapid renal tubular secretion (probenecid inhibits secretion, prolonging penicillin half-life)"
    },
    "safetyAndHazards": {
      "hazardLevel": "High",
      "ghsPictograms": [
        "GHS08_Health_Hazard",
        "GHS07_Harmful"
      ],
      "ghsSignalWord": "Danger",
      "hazardStatements": [
        "H317: May cause an allergic skin reaction",
        "H334: May cause allergy or asthma symptoms or breathing difficulties if inhaled"
      ],
      "precautionaryMeasures": [
        "P261: Avoid breathing dust/fume/spray",
        "P284: In case of inadequate ventilation wear respiratory protection",
        "P304+P340: IF INHALED: Remove person to fresh air"
      ],
      "ppeRequired": [
        "Double Nitrile Gloves",
        "N95 Respirator or HEPA-filtered laminar bench",
        "Protective Lab Gown"
      ],
      "disposalProtocol": "Deactivate with dilute sodium hydroxide or bleach prior to organic waste destruction."
    },
    "synthesisRoute": {
      "summary": "Industrial scale semi-synthesis relies on deep-tank aerobic fermentation of Penicillium chrysogenum supplemented with phenylacetic acid precursor, followed by filtration, solvent extraction, and crystallization.",
      "greenChemistryScore": 92,
      "steps": [
        {
          "stepNumber": 1,
          "reactionName": "Biosynthetic Fermentation",
          "reactants": [
            "Corn steep liquor",
            "Glucose / Lactose",
            "Phenylacetic acid precursor"
          ],
          "reagents": [
            "Penicillium chrysogenum inoculum",
            "Dissolved oxygen (aerated)"
          ],
          "conditions": "25°C, pH controlled 6.5–6.8 for 120–160 hours",
          "yield": "50 g/L broth titer",
          "notes": "Tripeptide ACV (aminoadipyl-cysteinyl-valine) enzymatically cyclized by isopenicillin N synthase (IPNS)."
        },
        {
          "stepNumber": 2,
          "reactionName": "Acidification & Liquid-Liquid Extraction",
          "reactants": [
            "Clarified mycelial filtrate"
          ],
          "reagents": [
            "Sulfuric acid (pH adjusted to 2.0–2.5)",
            "Butyl acetate or Methyl isobutyl ketone (MIBK)"
          ],
          "conditions": "Centrifugal extractor at 2–4°C (chilled to prevent β-lactam hydrolysis)",
          "yield": "95% extraction efficiency",
          "notes": "Penicillin free acid partitions into cold organic phase."
        },
        {
          "stepNumber": 3,
          "reactionName": "Back-Extraction & Crystallization",
          "reactants": [
            "Organic penicillin solution"
          ],
          "reagents": [
            "Potassium acetate in n-butanol or aqueous KOH"
          ],
          "conditions": "Crystallization at 15°C, filtered, vacuum-dried",
          "yield": "93%",
          "notes": "Produces ultra-pure crystalline Penicillin G potassium USP."
        }
      ]
    },
    "spectroscopy": {
      "irPeaks": [
        {
          "wavenumber": 1780,
          "intensity": "Strong",
          "bond": "C=O",
          "functionalGroup": "Strained 4-membered β-lactam carbonyl"
        },
        {
          "wavenumber": 1740,
          "intensity": "Strong",
          "bond": "C=O",
          "functionalGroup": "Carboxylic acid carbonyl"
        },
        {
          "wavenumber": 1660,
          "intensity": "Strong",
          "bond": "C=O",
          "functionalGroup": "Secondary amide (Amide I)"
        },
        {
          "wavenumber": 1530,
          "intensity": "Medium",
          "bond": "N-H / C-N",
          "functionalGroup": "Amide II band"
        }
      ],
      "uvVisMax": "257 nm (in methanol, ε = 850 M⁻¹cm⁻¹ due to phenyl group)",
      "nmr1H": "δ 1.55 (s, 3H, CH3), 1.62 (s, 3H, CH3), 3.65 (s, 2H, Ar-CH2), 4.35 (s, 1H, C3-H), 5.48 (d, 1H, C5-H), 5.62 (dd, 1H, C6-H), 7.28–7.36 (m, 5H, Ar-H)",
      "nmr13C": "δ 27.2 (CH3), 32.1 (CH3), 43.1 (Ar-CH2), 58.6 (C6), 64.9 (C5), 65.2 (C2), 70.8 (C3), 127.3 (CH), 128.9 (CH), 129.5 (CH), 135.2 (C-Ar), 168.2 (COOH), 171.4 (Amide C=O), 174.5 (β-lactam C=O)"
    },
    "practicalApplications": [
      "Treatment of Treponema pallidum (Syphilis) - still 1st-line drug of choice",
      "Streptococcal pharyngitis, necrotizing fasciitis, and bacterial endocarditis",
      "Neurosyphilis and congenital syphilis therapies"
    ],
    "atoms3D": [
      {
        "id": 0,
        "element": "S",
        "symbol": "S",
        "x": -0.85,
        "y": -0.62,
        "z": -0.42
      },
      {
        "id": 1,
        "element": "C",
        "symbol": "C",
        "x": 0.88,
        "y": -0.32,
        "z": -0.15
      },
      {
        "id": 2,
        "element": "C",
        "symbol": "C",
        "x": 0.82,
        "y": 1.15,
        "z": 0.35
      },
      {
        "id": 3,
        "element": "N",
        "symbol": "N",
        "x": -0.58,
        "y": 1.48,
        "z": 0.12
      },
      {
        "id": 4,
        "element": "C",
        "symbol": "C",
        "x": -1.35,
        "y": 0.65,
        "z": -0.65
      },
      {
        "id": 5,
        "element": "C",
        "symbol": "C",
        "x": -1.15,
        "y": 2.65,
        "z": 0.72
      },
      {
        "id": 6,
        "element": "O",
        "symbol": "O",
        "x": -2.12,
        "y": 3.32,
        "z": 0.95
      },
      {
        "id": 7,
        "element": "C",
        "symbol": "C",
        "x": 1.62,
        "y": -0.51,
        "z": -1.48
      },
      {
        "id": 8,
        "element": "C",
        "symbol": "C",
        "x": 1.51,
        "y": -1.18,
        "z": 0.95
      },
      {
        "id": 9,
        "element": "C",
        "symbol": "C",
        "x": 1.25,
        "y": 2.18,
        "z": -0.72
      },
      {
        "id": 10,
        "element": "N",
        "symbol": "N",
        "x": 2.65,
        "y": 2.38,
        "z": -0.82
      },
      {
        "id": 11,
        "element": "C",
        "symbol": "C",
        "x": 3.35,
        "y": 3.25,
        "z": -0.12
      },
      {
        "id": 12,
        "element": "O",
        "symbol": "O",
        "x": 2.82,
        "y": 4.02,
        "z": 0.68
      },
      {
        "id": 13,
        "element": "C",
        "symbol": "C",
        "x": 4.85,
        "y": 3.15,
        "z": -0.38
      },
      {
        "id": 14,
        "element": "C",
        "symbol": "C",
        "x": 5.65,
        "y": 4.38,
        "z": -0.05
      },
      {
        "id": 15,
        "element": "C",
        "symbol": "C",
        "x": 6.95,
        "y": 4.35,
        "z": -0.45
      },
      {
        "id": 16,
        "element": "C",
        "symbol": "C",
        "x": 7.72,
        "y": 5.48,
        "z": -0.15
      },
      {
        "id": 17,
        "element": "C",
        "symbol": "C",
        "x": 7.18,
        "y": 6.62,
        "z": 0.55
      },
      {
        "id": 18,
        "element": "C",
        "symbol": "C",
        "x": 5.88,
        "y": 6.65,
        "z": 0.95
      },
      {
        "id": 19,
        "element": "C",
        "symbol": "C",
        "x": 5.12,
        "y": 5.52,
        "z": 0.65
      },
      {
        "id": 20,
        "element": "C",
        "symbol": "C",
        "x": -0.32,
        "y": 2.88,
        "z": 0.35
      },
      {
        "id": 21,
        "element": "O",
        "symbol": "O",
        "x": 0.52,
        "y": 3.85,
        "z": 0.25
      },
      {
        "id": 22,
        "element": "O",
        "symbol": "O",
        "x": -0.45,
        "y": 3.12,
        "z": 1.62
      }
    ],
    "bonds3D": [
      {
        "source": 0,
        "target": 1,
        "order": 1
      },
      {
        "source": 0,
        "target": 4,
        "order": 1
      },
      {
        "source": 1,
        "target": 2,
        "order": 1
      },
      {
        "source": 1,
        "target": 7,
        "order": 1
      },
      {
        "source": 1,
        "target": 8,
        "order": 1
      },
      {
        "source": 2,
        "target": 3,
        "order": 1
      },
      {
        "source": 2,
        "target": 9,
        "order": 1
      },
      {
        "source": 3,
        "target": 4,
        "order": 1
      },
      {
        "source": 3,
        "target": 5,
        "order": 1
      },
      {
        "source": 4,
        "target": 20,
        "order": 1
      },
      {
        "source": 5,
        "target": 6,
        "order": 2
      },
      {
        "source": 5,
        "target": 20,
        "order": 1
      },
      {
        "source": 20,
        "target": 21,
        "order": 2
      },
      {
        "source": 20,
        "target": 22,
        "order": 1
      },
      {
        "source": 9,
        "target": 10,
        "order": 1
      },
      {
        "source": 10,
        "target": 11,
        "order": 1
      },
      {
        "source": 11,
        "target": 12,
        "order": 2
      },
      {
        "source": 11,
        "target": 13,
        "order": 1
      },
      {
        "source": 13,
        "target": 14,
        "order": 1
      },
      {
        "source": 14,
        "target": 15,
        "order": 2
      },
      {
        "source": 15,
        "target": 16,
        "order": 1
      },
      {
        "source": 16,
        "target": 17,
        "order": 2
      },
      {
        "source": 17,
        "target": 18,
        "order": 1
      },
      {
        "source": 18,
        "target": 19,
        "order": 2
      },
      {
        "source": 19,
        "target": 14,
        "order": 1
      }
    ]
  },
  {
    "id": "ibuprofen",
    "name": "Ibuprofen",
    "iupacName": "(2RS)-2-[4-(2-Methylpropyl)phenyl]propanoic acid",
    "formula": "C13H18O2",
    "smiles": "CC(C)CC1=CC=C(C=C1)C(C)C(=O)O",
    "inchiKey": "HEXESARFPSRMLM-UHFFFAOYSA-N",
    "casNumber": "15687-27-1",
    "category": "NSAID / Propionic Acid Derivative",
    "description": "Widely used non-steroidal anti-inflammatory drug (NSAID) that acts as a non-selective inhibitor of cyclooxygenases COX-1 and COX-2, decreasing prostaglandin synthesis and reducing inflammation, fever, and pain.",
    "properties": {
      "molecularWeight": 206.28,
      "logP": 3.5,
      "tpsa": 37.3,
      "hBondDonors": 1,
      "hBondAcceptors": 2,
      "rotatableBonds": 4,
      "heavyAtomCount": 15,
      "charge": 0,
      "solubility": "0.021 mg/mL in H2O at 25°C (lipophilic)",
      "meltingPoint": "75–78 °C",
      "boilingPoint": "157 °C at 4 mmHg",
      "density": "1.03 g/cm³"
    },
    "lipinskiRuleOf5": {
      "passed": true,
      "violations": 0,
      "details": "Ideal drug-like properties according to Lipinski: MW 206.3 < 500, LogP 3.50 < 5, Donors 1 < 5, Acceptors 2 < 10.",
      "mwPass": true,
      "logPPass": true,
      "donorsPass": true,
      "acceptorsPass": true
    },
    "pharmacology": {
      "mechanismOfAction": "Reversible non-selective competitive inhibition of COX-1 and COX-2, inhibiting conversion of arachidonic acid to prostaglandin H2.",
      "targetReceptors": [
        "COX-1",
        "COX-2",
        "PPAR-gamma (weak agonist)"
      ],
      "bioavailability": "80–100% oral absorption",
      "halfLife": "1.8 – 2.0 hours",
      "metabolism": "Extensive hepatic CYP2C9 oxidation to hydroxylated and carboxylated metabolites.",
      "clearance": "Renal (90% excreted as inactive metabolites or glucuronide conjugates)"
    },
    "safetyAndHazards": {
      "hazardLevel": "Low",
      "ghsPictograms": [
        "GHS07_Harmful"
      ],
      "ghsSignalWord": "Warning",
      "hazardStatements": [
        "H302: Harmful if swallowed",
        "H319: Causes serious eye irritation"
      ],
      "precautionaryMeasures": [
        "P280: Wear eye protection and gloves",
        "P301+P312: IF SWALLOWED: Call a poison center if unwell"
      ],
      "ppeRequired": [
        "Nitrile Gloves",
        "Eye Protection"
      ],
      "disposalProtocol": "Hazardous pharmaceutical waste disposal regulations."
    },
    "synthesisRoute": {
      "summary": "Famous Boots-Hoechst-Celanese (BHC) Green synthesis: 3-step catalytic pathway with 77% atom economy replacing the older 6-step stoichiometric Boots process.",
      "greenChemistryScore": 96,
      "steps": [
        {
          "stepNumber": 1,
          "reactionName": "Friedel-Crafts Acylation",
          "reactants": [
            "Isobutylbenzene",
            "Acetic anhydride"
          ],
          "reagents": [
            "Anhydrous HF catalyst (recovered and recycled)"
          ],
          "conditions": "70°C, 1 hour",
          "yield": "99%",
          "notes": "Produces 4-isobutylacetophenone with zero halogen waste."
        },
        {
          "stepNumber": 2,
          "reactionName": "Catalytic Hydrogenation",
          "reactants": [
            "4-Isobutylacetophenone"
          ],
          "reagents": [
            "Raney Ni or Pd/C catalyst",
            "H2 gas (5 bar)"
          ],
          "conditions": "50°C in alcohol solvent",
          "yield": "98%",
          "notes": "Quantitative reduction of ketone to 1-(4-isobutylphenyl)ethanol."
        },
        {
          "stepNumber": 3,
          "reactionName": "Carbonylation",
          "reactants": [
            "1-(4-Isobutylphenyl)ethanol",
            "Carbon monoxide (CO)"
          ],
          "reagents": [
            "Pd(PPh3)2Cl2 catalyst",
            "Aqueous acid"
          ],
          "conditions": "130°C, 40 bar CO pressure",
          "yield": "96%",
          "notes": "Insertion of CO directly forms racemic ibuprofen with no waste byproducts."
        }
      ]
    },
    "spectroscopy": {
      "irPeaks": [
        {
          "wavenumber": 1709,
          "intensity": "Strong",
          "bond": "C=O",
          "functionalGroup": "Carboxylic acid carbonyl"
        },
        {
          "wavenumber": 2955,
          "intensity": "Strong",
          "bond": "C-H",
          "functionalGroup": "Isobutyl aliphatic stretching"
        },
        {
          "wavenumber": 1510,
          "intensity": "Medium",
          "bond": "C=C",
          "functionalGroup": "Para-disubstituted benzene ring"
        }
      ],
      "uvVisMax": "264 nm, 273 nm",
      "nmr1H": "δ 0.90 (d, 6H, 2x CH3), 1.50 (d, 3H, CH3), 1.84 (m, 1H, CH), 2.45 (d, 2H, CH2), 3.71 (q, 1H, CH-COOH), 7.10 (d, 2H, Ar-H), 7.22 (d, 2H, Ar-H), 11.2 (br s, 1H, COOH)",
      "nmr13C": "δ 18.2, 22.4, 30.2, 45.0, 45.1, 127.3, 129.4, 137.2, 140.6, 181.1"
    },
    "practicalApplications": [
      "Treatment of fever, mild-to-moderate pain, and primary dysmenorrhea",
      "Management of rheumatoid arthritis and osteoarthritis",
      "Closure of patent ductus arteriosus in premature infants"
    ],
    "atoms3D": [
      {
        "id": 0,
        "element": "C",
        "symbol": "C",
        "x": -1.4,
        "y": 0,
        "z": 0
      },
      {
        "id": 1,
        "element": "C",
        "symbol": "C",
        "x": -0.7,
        "y": 1.2,
        "z": 0
      },
      {
        "id": 2,
        "element": "C",
        "symbol": "C",
        "x": 0.7,
        "y": 1.2,
        "z": 0
      },
      {
        "id": 3,
        "element": "C",
        "symbol": "C",
        "x": 1.4,
        "y": 0,
        "z": 0
      },
      {
        "id": 4,
        "element": "C",
        "symbol": "C",
        "x": 0.7,
        "y": -1.2,
        "z": 0
      },
      {
        "id": 5,
        "element": "C",
        "symbol": "C",
        "x": -0.7,
        "y": -1.2,
        "z": 0
      },
      {
        "id": 6,
        "element": "C",
        "symbol": "C",
        "x": -2.9,
        "y": 0,
        "z": 0
      },
      {
        "id": 7,
        "element": "C",
        "symbol": "C",
        "x": -3.5,
        "y": -1.2,
        "z": -0.7
      },
      {
        "id": 8,
        "element": "C",
        "symbol": "C",
        "x": -4.9,
        "y": -0.9,
        "z": -1.1
      },
      {
        "id": 9,
        "element": "C",
        "symbol": "C",
        "x": -3.4,
        "y": -2.4,
        "z": 0.2
      },
      {
        "id": 10,
        "element": "C",
        "symbol": "C",
        "x": 2.9,
        "y": 0,
        "z": 0
      },
      {
        "id": 11,
        "element": "C",
        "symbol": "C",
        "x": 3.5,
        "y": 1.3,
        "z": 0.6
      },
      {
        "id": 12,
        "element": "C",
        "symbol": "C",
        "x": 3.5,
        "y": -1.2,
        "z": -0.6
      },
      {
        "id": 13,
        "element": "O",
        "symbol": "O",
        "x": 3.1,
        "y": -2.3,
        "z": -0.4
      },
      {
        "id": 14,
        "element": "O",
        "symbol": "O",
        "x": 4.6,
        "y": -1,
        "z": -1.4
      },
      {
        "id": 15,
        "element": "H",
        "symbol": "H",
        "x": 4.9,
        "y": -1.8,
        "z": -1.7
      },
      {
        "id": 16,
        "element": "H",
        "symbol": "H",
        "x": -1.2,
        "y": 2.1,
        "z": 0
      },
      {
        "id": 17,
        "element": "H",
        "symbol": "H",
        "x": 1.2,
        "y": 2.1,
        "z": 0
      },
      {
        "id": 18,
        "element": "H",
        "symbol": "H",
        "x": 1.2,
        "y": -2.1,
        "z": 0
      },
      {
        "id": 19,
        "element": "H",
        "symbol": "H",
        "x": -1.2,
        "y": -2.1,
        "z": 0
      }
    ],
    "bonds3D": [
      {
        "source": 0,
        "target": 1,
        "order": 2
      },
      {
        "source": 1,
        "target": 2,
        "order": 1
      },
      {
        "source": 2,
        "target": 3,
        "order": 2
      },
      {
        "source": 3,
        "target": 4,
        "order": 1
      },
      {
        "source": 4,
        "target": 5,
        "order": 2
      },
      {
        "source": 5,
        "target": 0,
        "order": 1
      },
      {
        "source": 0,
        "target": 6,
        "order": 1
      },
      {
        "source": 6,
        "target": 7,
        "order": 1
      },
      {
        "source": 7,
        "target": 8,
        "order": 1
      },
      {
        "source": 7,
        "target": 9,
        "order": 1
      },
      {
        "source": 3,
        "target": 10,
        "order": 1
      },
      {
        "source": 10,
        "target": 11,
        "order": 1
      },
      {
        "source": 10,
        "target": 12,
        "order": 1
      },
      {
        "source": 12,
        "target": 13,
        "order": 2
      },
      {
        "source": 12,
        "target": 14,
        "order": 1
      },
      {
        "source": 14,
        "target": 15,
        "order": 1
      },
      {
        "source": 1,
        "target": 16,
        "order": 1
      },
      {
        "source": 2,
        "target": 17,
        "order": 1
      },
      {
        "source": 4,
        "target": 18,
        "order": 1
      },
      {
        "source": 5,
        "target": 19,
        "order": 1
      }
    ]
  },
  {
    "id": "melatonin",
    "name": "Melatonin",
    "iupacName": "N-[2-(5-Methoxy-1H-indol-3-yl)ethyl]acetamide",
    "formula": "C13H16N2O2",
    "smiles": "CC(=O)NCCC1=CNC2=C1C=C(C=C2)OC",
    "inchiKey": "LELKPDRGOKPAGB-UHFFFAOYSA-N",
    "casNumber": "73-31-4",
    "category": "Indoleamine / Pineal Neurohormone",
    "description": "An endogenous indoleamine neurohormone synthesized by the pineal gland that synchronizes circadian sleep-wake cycles, displays potent direct antioxidant radical-scavenging activity, and modulates immune responses.",
    "properties": {
      "molecularWeight": 232.28,
      "logP": 1.6,
      "tpsa": 54.7,
      "hBondDonors": 2,
      "hBondAcceptors": 2,
      "rotatableBonds": 4,
      "heavyAtomCount": 17,
      "charge": 0,
      "solubility": "0.1 mg/mL in H2O at 20°C",
      "meltingPoint": "116–118 °C",
      "boilingPoint": "512.8 °C",
      "density": "1.20 g/cm³"
    },
    "lipinskiRuleOf5": {
      "passed": true,
      "violations": 0,
      "details": "Exemplary Lipinski druglikeness (MW 232.3, LogP 1.60, 2 Donors, 2 Acceptors).",
      "mwPass": true,
      "logPPass": true,
      "donorsPass": true,
      "acceptorsPass": true
    },
    "pharmacology": {
      "mechanismOfAction": "High-affinity agonist at MT1 (inactivates SCN neuronal firing) and MT2 (phase-shifts circadian clock) G-protein coupled receptors.",
      "targetReceptors": [
        "Melatonin MT1 Receptor",
        "Melatonin MT2 Receptor",
        "Calmodulin (intracellular target)",
        "Direct scavenger of hydroxyl & peroxyl radicals"
      ],
      "bioavailability": "15% oral (high first-pass hepatic metabolism)",
      "halfLife": "30 – 50 minutes",
      "metabolism": "Hepatic 6-hydroxylation via CYP1A2, then sulfate and glucuronide conjugation.",
      "clearance": "Renal (mostly 6-sulfatoxymelatonin)"
    },
    "safetyAndHazards": {
      "hazardLevel": "Low",
      "ghsPictograms": [],
      "ghsSignalWord": "Caution",
      "hazardStatements": [
        "H316: Causes mild skin irritation (rare)"
      ],
      "precautionaryMeasures": [
        "P262: Do not get in eyes"
      ],
      "ppeRequired": [
        "Standard Lab Gloves"
      ],
      "disposalProtocol": "Normal sanitary pharmaceutical solid waste."
    },
    "synthesisRoute": {
      "summary": "Biomimetic synthesis from 5-methoxytryptamine via selective N-acetylation with acetic anhydride in pyridine or aqueous base.",
      "greenChemistryScore": 94,
      "steps": [
        {
          "stepNumber": 1,
          "reactionName": "Fischer Indole Synthesis",
          "reactants": [
            "4-Methoxyphenylhydrazine",
            "4-Chlorobutanal"
          ],
          "reagents": [
            "Aqueous ethanol",
            "Acid catalyst"
          ],
          "conditions": "Reflux at 85°C",
          "yield": "78%",
          "notes": "Produces 5-methoxytryptamine core scaffold."
        },
        {
          "stepNumber": 2,
          "reactionName": "N-Acetylation",
          "reactants": [
            "5-Methoxytryptamine",
            "Acetic anhydride"
          ],
          "reagents": [
            "Triethylamine catalyst",
            "Ethyl acetate solvent"
          ],
          "conditions": "Room temperature for 1 hour",
          "yield": "95%",
          "notes": "Clean precipitation and recrystallization from hot ethanol/water."
        }
      ]
    },
    "spectroscopy": {
      "irPeaks": [
        {
          "wavenumber": 3310,
          "intensity": "Medium",
          "bond": "N-H",
          "functionalGroup": "Indole NH & Amide NH"
        },
        {
          "wavenumber": 1630,
          "intensity": "Strong",
          "bond": "C=O",
          "functionalGroup": "Secondary amide"
        },
        {
          "wavenumber": 1215,
          "intensity": "Strong",
          "bond": "C-O-C",
          "functionalGroup": "Aryl methyl ether"
        }
      ],
      "uvVisMax": "278 nm",
      "nmr1H": "δ 1.95 (s, 3H, CO-CH3), 2.92 (t, 2H, CH2), 3.51 (q, 2H, CH2-N), 3.86 (s, 3H, O-CH3), 6.84 (dd, 1H, Ar-H), 7.04 (d, 1H, Ar-H), 7.15 (d, 1H, Indole-H2), 7.26 (d, 1H, Ar-H), 8.1 (br s, 1H, Indole-NH)",
      "nmr13C": "δ 23.2, 25.4, 39.8, 55.9, 100.3, 111.7, 112.3, 112.4, 123.5, 127.8, 131.7, 153.9, 170.3"
    },
    "practicalApplications": [
      "Circadian rhythm sleep disorders and jet lag resynchronization",
      "Adjunct neuroprotective antioxidant research in neurodegenerative pathologies",
      "Sleep onset latency reduction in insomnia"
    ],
    "atoms3D": [
      {
        "id": 0,
        "element": "C",
        "symbol": "C",
        "x": -2.5,
        "y": -0.5,
        "z": 0
      },
      {
        "id": 1,
        "element": "C",
        "symbol": "C",
        "x": -1.8,
        "y": 0.7,
        "z": 0
      },
      {
        "id": 2,
        "element": "C",
        "symbol": "C",
        "x": -0.4,
        "y": 0.7,
        "z": 0
      },
      {
        "id": 3,
        "element": "C",
        "symbol": "C",
        "x": 0.3,
        "y": -0.5,
        "z": 0
      },
      {
        "id": 4,
        "element": "C",
        "symbol": "C",
        "x": -0.4,
        "y": -1.7,
        "z": 0
      },
      {
        "id": 5,
        "element": "C",
        "symbol": "C",
        "x": -1.8,
        "y": -1.7,
        "z": 0
      },
      {
        "id": 6,
        "element": "O",
        "symbol": "O",
        "x": -3.8,
        "y": -0.5,
        "z": 0
      },
      {
        "id": 7,
        "element": "C",
        "symbol": "C",
        "x": -4.6,
        "y": 0.6,
        "z": 0
      },
      {
        "id": 8,
        "element": "N",
        "symbol": "N",
        "x": 1.7,
        "y": -0.8,
        "z": 0
      },
      {
        "id": 9,
        "element": "C",
        "symbol": "C",
        "x": 2.3,
        "y": 0.4,
        "z": 0
      },
      {
        "id": 10,
        "element": "C",
        "symbol": "C",
        "x": 1.7,
        "y": 1.6,
        "z": 0
      },
      {
        "id": 11,
        "element": "C",
        "symbol": "C",
        "x": 0.3,
        "y": 2,
        "z": 0
      },
      {
        "id": 12,
        "element": "C",
        "symbol": "C",
        "x": 2.5,
        "y": 2.9,
        "z": 0
      },
      {
        "id": 13,
        "element": "C",
        "symbol": "C",
        "x": 3.9,
        "y": 2.6,
        "z": -0.3
      },
      {
        "id": 14,
        "element": "N",
        "symbol": "N",
        "x": 4.8,
        "y": 3.7,
        "z": -0.3
      },
      {
        "id": 15,
        "element": "C",
        "symbol": "C",
        "x": 6.1,
        "y": 3.6,
        "z": 0.1
      },
      {
        "id": 16,
        "element": "O",
        "symbol": "O",
        "x": 6.7,
        "y": 2.6,
        "z": 0.6
      },
      {
        "id": 17,
        "element": "C",
        "symbol": "C",
        "x": 6.8,
        "y": 4.9,
        "z": -0.2
      }
    ],
    "bonds3D": [
      {
        "source": 0,
        "target": 1,
        "order": 2
      },
      {
        "source": 1,
        "target": 2,
        "order": 1
      },
      {
        "source": 2,
        "target": 3,
        "order": 2
      },
      {
        "source": 3,
        "target": 4,
        "order": 1
      },
      {
        "source": 4,
        "target": 5,
        "order": 2
      },
      {
        "source": 5,
        "target": 0,
        "order": 1
      },
      {
        "source": 0,
        "target": 6,
        "order": 1
      },
      {
        "source": 6,
        "target": 7,
        "order": 1
      },
      {
        "source": 3,
        "target": 8,
        "order": 1
      },
      {
        "source": 8,
        "target": 9,
        "order": 1
      },
      {
        "source": 9,
        "target": 10,
        "order": 2
      },
      {
        "source": 10,
        "target": 2,
        "order": 1
      },
      {
        "source": 10,
        "target": 12,
        "order": 1
      },
      {
        "source": 12,
        "target": 13,
        "order": 1
      },
      {
        "source": 13,
        "target": 14,
        "order": 1
      },
      {
        "source": 14,
        "target": 15,
        "order": 1
      },
      {
        "source": 15,
        "target": 16,
        "order": 2
      },
      {
        "source": 15,
        "target": 17,
        "order": 1
      }
    ]
  },
  {
    "id": "paracetamol",
    "name": "Paracetamol (Acetaminophen)",
    "iupacName": "N-(4-hydroxyphenyl)acetamide",
    "formula": "C8H9NO2",
    "smiles": "CC(=O)NC1=CC=C(C=C1)O",
    "inchiKey": "RZVAJINKPMORJF-UHFFFAOYSA-N",
    "casNumber": "103-90-2",
    "category": "Analgesic / Antipyretic",
    "description": "Widely used analgesic and antipyretic drug that acts primarily in the central nervous system to inhibit prostaglandin synthesis via peroxidase site inhibition on COX enzymes without significant peripheral anti-inflammatory effects.",
    "properties": {
      "molecularWeight": 151.16,
      "logP": 0.46,
      "tpsa": 49.3,
      "hBondDonors": 2,
      "hBondAcceptors": 2,
      "rotatableBonds": 1,
      "heavyAtomCount": 11,
      "charge": 0,
      "solubility": "14.3 mg/mL in H2O at 25°C",
      "meltingPoint": "169–171 °C",
      "boilingPoint": "420 °C",
      "density": "1.29 g/cm³"
    },
    "lipinskiRuleOf5": {
      "passed": true,
      "violations": 0,
      "details": "Meets all 4 Lipinski criteria (MW 151.2 < 500, LogP 0.46 < 5, 2 Donors, 2 Acceptors). High oral bioavailability with minimal plasma protein binding.",
      "mwPass": true,
      "logPPass": true,
      "donorsPass": true,
      "acceptorsPass": true
    },
    "pharmacology": {
      "mechanismOfAction": "Inhibition of central prostaglandin synthesis by scavenging free radicals and blocking COX-1/COX-2 peroxidase active sites; activation of descending serotonergic pathways and cannabinoid CB1 receptor indirect agonism via AM404 metabolite.",
      "targetReceptors": [
        "COX-1 (Peroxidase catalytic site)",
        "COX-2 (Peroxidase site)",
        "TRPV1 receptor",
        "Cannabinoid CB1 (via AM404)"
      ],
      "bioavailability": "63–89% oral absorption",
      "halfLife": "1.5 – 2.5 hours",
      "metabolism": "Hepatic glucuronidation (55%) and sulfation (30%); small fraction oxidized by CYP2E1 to NAPQI, detoxified by glutathione.",
      "clearance": "Renal (90% excreted within 24 hours as inactive glucuronide/sulfate conjugates)"
    },
    "safetyAndHazards": {
      "hazardLevel": "Moderate",
      "ghsPictograms": [
        "GHS07_Harmful"
      ],
      "ghsSignalWord": "Warning",
      "hazardStatements": [
        "H302: Harmful if swallowed",
        "H317: May cause allergic skin reaction"
      ],
      "precautionaryMeasures": [
        "P280: Wear protective gloves",
        "P301+P312: IF SWALLOWED: Call poison center if unwell"
      ],
      "ppeRequired": [
        "Nitrile Gloves",
        "Safety Glasses",
        "Lab Coat"
      ],
      "disposalProtocol": "Hazardous pharmaceutical incineration or authorized biological waste pickup."
    },
    "synthesisRoute": {
      "summary": "Industrial preparation via nitration of phenol, separation of 4-nitrophenol, catalytic hydrogenation to 4-aminophenol, followed by selective N-acetylation with acetic anhydride.",
      "greenChemistryScore": 88,
      "steps": [
        {
          "stepNumber": 1,
          "reactionName": "Phenol Nitration",
          "reactants": [
            "Phenol",
            "Dilute Nitric Acid"
          ],
          "reagents": [
            "Aqueous HNO3"
          ],
          "conditions": "20–25°C, steam distillation to isolate 4-isomer",
          "yield": "45%",
          "notes": "Produces ortho and para-nitrophenol isomers."
        },
        {
          "stepNumber": 2,
          "reactionName": "Catalytic Hydrogenation",
          "reactants": [
            "4-Nitrophenol"
          ],
          "reagents": [
            "H2 gas",
            "Pd/C catalyst"
          ],
          "conditions": "50°C, 3 bar in ethanol",
          "yield": "94%",
          "notes": "Reduction of nitro group yields 4-aminophenol."
        },
        {
          "stepNumber": 3,
          "reactionName": "N-Acetylation",
          "reactants": [
            "4-Aminophenol",
            "Acetic Anhydride"
          ],
          "reagents": [
            "Aqueous suspension / catalytic pyridine"
          ],
          "conditions": "Reflux at 100°C for 30 minutes",
          "yield": "92%",
          "notes": "Paracetamol precipitates out cleanly upon cooling; recrystallized from hot water."
        }
      ]
    },
    "spectroscopy": {
      "irPeaks": [
        {
          "wavenumber": 3325,
          "intensity": "Broad",
          "bond": "O-H",
          "functionalGroup": "Phenolic hydroxyl group"
        },
        {
          "wavenumber": 3160,
          "intensity": "Medium",
          "bond": "N-H",
          "functionalGroup": "Secondary amide stretch"
        },
        {
          "wavenumber": 1650,
          "intensity": "Strong",
          "bond": "C=O",
          "functionalGroup": "Amide carbonyl (Amide I)"
        },
        {
          "wavenumber": 1565,
          "intensity": "Strong",
          "bond": "C-N / N-H",
          "functionalGroup": "Amide II band"
        }
      ],
      "uvVisMax": "243 nm (in water, ε = 13,800 M⁻¹cm⁻¹)",
      "nmr1H": "δ 2.05 (s, 3H, CH3), 6.68 (d, 2H, Ar-H), 7.34 (d, 2H, Ar-H), 9.12 (br s, 1H, OH), 9.65 (br s, 1H, NH)",
      "nmr13C": "δ 24.1 (CH3), 115.3 (2x Ar-CH), 121.0 (2x Ar-CH), 131.2 (Ar-C-N), 153.4 (Ar-C-O), 168.0 (C=O)"
    },
    "practicalApplications": [
      "First-line treatment for mild-to-moderate analgesia and pyrexia",
      "Preferred pain therapy in patients with gastric ulcer or bleeding diathesis",
      "Pediatric antipyretic formulations"
    ],
    "atoms3D": [
      {
        "id": 0,
        "element": "C",
        "symbol": "C",
        "x": -1.2,
        "y": 0,
        "z": 0
      },
      {
        "id": 1,
        "element": "C",
        "symbol": "C",
        "x": -0.5,
        "y": 1.2,
        "z": 0
      },
      {
        "id": 2,
        "element": "C",
        "symbol": "C",
        "x": 0.9,
        "y": 1.2,
        "z": 0
      },
      {
        "id": 3,
        "element": "C",
        "symbol": "C",
        "x": 1.6,
        "y": 0,
        "z": 0
      },
      {
        "id": 4,
        "element": "C",
        "symbol": "C",
        "x": 0.9,
        "y": -1.2,
        "z": 0
      },
      {
        "id": 5,
        "element": "C",
        "symbol": "C",
        "x": -0.5,
        "y": -1.2,
        "z": 0
      },
      {
        "id": 6,
        "element": "O",
        "symbol": "O",
        "x": -2.55,
        "y": 0,
        "z": 0
      },
      {
        "id": 7,
        "element": "N",
        "symbol": "N",
        "x": 3,
        "y": 0,
        "z": 0
      },
      {
        "id": 8,
        "element": "C",
        "symbol": "C",
        "x": 3.75,
        "y": 1.15,
        "z": 0
      },
      {
        "id": 9,
        "element": "O",
        "symbol": "O",
        "x": 3.25,
        "y": 2.25,
        "z": 0
      },
      {
        "id": 10,
        "element": "C",
        "symbol": "C",
        "x": 5.25,
        "y": 0.95,
        "z": 0
      },
      {
        "id": 11,
        "element": "H",
        "symbol": "H",
        "x": -2.9,
        "y": 0.9,
        "z": 0
      },
      {
        "id": 12,
        "element": "H",
        "symbol": "H",
        "x": 3.45,
        "y": -0.9,
        "z": 0
      },
      {
        "id": 13,
        "element": "H",
        "symbol": "H",
        "x": -1,
        "y": 2.15,
        "z": 0
      },
      {
        "id": 14,
        "element": "H",
        "symbol": "H",
        "x": 1.45,
        "y": 2.15,
        "z": 0
      },
      {
        "id": 15,
        "element": "H",
        "symbol": "H",
        "x": 1.45,
        "y": -2.15,
        "z": 0
      },
      {
        "id": 16,
        "element": "H",
        "symbol": "H",
        "x": -1,
        "y": -2.15,
        "z": 0
      },
      {
        "id": 17,
        "element": "H",
        "symbol": "H",
        "x": 5.55,
        "y": 0.38,
        "z": 0.88
      },
      {
        "id": 18,
        "element": "H",
        "symbol": "H",
        "x": 5.55,
        "y": 0.38,
        "z": -0.88
      },
      {
        "id": 19,
        "element": "H",
        "symbol": "H",
        "x": 5.75,
        "y": 1.9,
        "z": 0
      }
    ],
    "bonds3D": [
      {
        "source": 0,
        "target": 1,
        "order": 2
      },
      {
        "source": 1,
        "target": 2,
        "order": 1
      },
      {
        "source": 2,
        "target": 3,
        "order": 2
      },
      {
        "source": 3,
        "target": 4,
        "order": 1
      },
      {
        "source": 4,
        "target": 5,
        "order": 2
      },
      {
        "source": 5,
        "target": 0,
        "order": 1
      },
      {
        "source": 0,
        "target": 6,
        "order": 1
      },
      {
        "source": 6,
        "target": 11,
        "order": 1
      },
      {
        "source": 3,
        "target": 7,
        "order": 1
      },
      {
        "source": 7,
        "target": 8,
        "order": 1
      },
      {
        "source": 7,
        "target": 12,
        "order": 1
      },
      {
        "source": 8,
        "target": 9,
        "order": 2
      },
      {
        "source": 8,
        "target": 10,
        "order": 1
      },
      {
        "source": 1,
        "target": 13,
        "order": 1
      },
      {
        "source": 2,
        "target": 14,
        "order": 1
      },
      {
        "source": 4,
        "target": 15,
        "order": 1
      },
      {
        "source": 5,
        "target": 16,
        "order": 1
      },
      {
        "source": 10,
        "target": 17,
        "order": 1
      },
      {
        "source": 10,
        "target": 18,
        "order": 1
      },
      {
        "source": 10,
        "target": 19,
        "order": 1
      }
    ]
  },
  {
    "id": "taxol",
    "name": "Taxol (Paclitaxel)",
    "iupacName": "(2aR,4aR,6R,9S,11S,12S,12aR,12bS)-6,12b-diacetyloxy-12-(benzoyloxy)-4,11-dihydroxy-4a,8,13,13-tetramethyl-5-oxo-2a,3,4,4a,5,6,9,10,11,12,12a,12b-dodecahydro-7,11-methanocyclodeca[3,4]benzo[1,2-b]oxete-9-yl (2R,3S)-3-(benzoylamino)-2-hydroxy-3-phenylpropanoate",
    "formula": "C47H51NO14",
    "smiles": "CC1=C2C(C(=O)C3(C(CC4C(C3C(C(C2(C)C)(CC1OC(=O)C(C(C5=CC=CC=C5)NC(=O)C6=CC=CC=C6)O)O)OC(=O)C7=CC=CC=C7)(CO4)OC(=O)C)O)C)OC(=O)C",
    "inchiKey": "RCINICONZNJXIF-FSZBPSSPSA-N",
    "casNumber": "33069-62-4",
    "category": "Antineoplastic / Microtubule Stabilizer",
    "description": "A potent diterpenoid alkaloid isolated from the Pacific yew (Taxus brevifolia) that hyper-stabilizes microtubules, arresting eukaryotic cancer cells in the G2/M mitotic phase and triggering programmed apoptosis.",
    "properties": {
      "molecularWeight": 853.91,
      "logP": 3.96,
      "tpsa": 221.3,
      "hBondDonors": 3,
      "hBondAcceptors": 14,
      "rotatableBonds": 14,
      "heavyAtomCount": 62,
      "charge": 0,
      "solubility": "0.005 mg/mL in H2O (hydrophobic; formulated in Cremophor EL/albumin)",
      "meltingPoint": "216–217 °C",
      "boilingPoint": "957 °C",
      "density": "1.39 g/cm³"
    },
    "lipinskiRuleOf5": {
      "passed": false,
      "violations": 2,
      "details": "Violates MW > 500 Da (853.9 Da) and H-Acceptors > 10 (14). Exceeds Rule of 5 like many complex natural macrocyclic anticancer therapeutics; administered via intravenous infusion.",
      "mwPass": false,
      "logPPass": true,
      "donorsPass": true,
      "acceptorsPass": false
    },
    "pharmacology": {
      "mechanismOfAction": "High-affinity binding to the β-tubulin subunit on the inner microtubule surface, promoting tubulin assembly and preventing depolymerization, freezing cell division spindle apparatus.",
      "targetReceptors": [
        "β-Tubulin",
        "Bcl-2 phosphorylation pathway",
        "Macrophage TLR-4 activation"
      ],
      "bioavailability": "Near 0% oral (intravenous administration mandatory)",
      "halfLife": "13 – 52 hours (triphasic elimination)",
      "metabolism": "Extensive hepatic metabolism mediated by CYP2C8 (to 6α-hydroxypaclitaxel) and CYP3A4.",
      "clearance": "Biliary and fecal excretion (> 70%); less than 14% renal excretion."
    },
    "safetyAndHazards": {
      "hazardLevel": "High",
      "ghsPictograms": [
        "GHS08_Health_Hazard",
        "GHS07_Harmful"
      ],
      "ghsSignalWord": "Danger",
      "hazardStatements": [
        "H341: Suspected of causing genetic defects",
        "H351: Suspected of causing cancer",
        "H360: May damage fertility or the unborn child"
      ],
      "precautionaryMeasures": [
        "P201: Obtain special instructions before use",
        "P281: Use personal protective equipment as required"
      ],
      "ppeRequired": [
        "Cytotoxic Chemotherapy Gloves",
        "Biological Safety Cabinet (Class II Type B)",
        "HEPA Powered Air Respirator"
      ],
      "disposalProtocol": "High-temperature hazardous chemotherapeutic incineration at 1000°C."
    },
    "synthesisRoute": {
      "summary": "Industrial semi-synthesis from renewable 10-deacetylbaccatin III (10-DAB) harvested from European yew needles, coupled with synthetic Ojima β-lactam side chain.",
      "greenChemistryScore": 72,
      "steps": [
        {
          "stepNumber": 1,
          "reactionName": "Harvesting & Extraction",
          "reactants": [
            "Taxus baccata foliage"
          ],
          "reagents": [
            "Methanol / Ethanol extraction",
            "C18 reverse-phase chromatography"
          ],
          "conditions": "Ambient temperature percolation",
          "yield": "0.1% biomass yield",
          "notes": "Yields 10-deacetylbaccatin III core skeleton."
        },
        {
          "stepNumber": 2,
          "reactionName": "C13 Side Chain Coupling",
          "reactants": [
            "Protected Baccatin III",
            "N-benzoyl-O-EE-phenylisoserine β-lactam"
          ],
          "reagents": [
            "Sodium hexamethyldisilazide (NaHMDS)"
          ],
          "conditions": "-40°C in anhydrous THF",
          "yield": "91%",
          "notes": "Diastereoselective ring opening stereospecifically establishes C13 ester."
        },
        {
          "stepNumber": 3,
          "reactionName": "Deprotection & Purification",
          "reactants": [
            "Coupled paclitaxel precursor"
          ],
          "reagents": [
            "TFA in dichloromethane"
          ],
          "conditions": "0°C for 2 hours",
          "yield": "96%",
          "notes": "Cleaves protective silyl/EE ethers to give paclitaxel USP."
        }
      ]
    },
    "spectroscopy": {
      "irPeaks": [
        {
          "wavenumber": 3450,
          "intensity": "Broad",
          "bond": "O-H",
          "functionalGroup": "Free hydroxyl groups"
        },
        {
          "wavenumber": 1735,
          "intensity": "Strong",
          "bond": "C=O",
          "functionalGroup": "Ester carbonyls (C4, C13, C10)"
        },
        {
          "wavenumber": 1650,
          "intensity": "Strong",
          "bond": "C=O",
          "functionalGroup": "Amide carbonyl"
        }
      ],
      "uvVisMax": "228 nm (in methanol, ε = 29,800 M⁻¹cm⁻¹ due to multiple phenyl rings)",
      "nmr1H": "δ 1.15 (s, 3H), 1.25 (s, 3H), 1.68 (s, 3H), 1.80 (s, 3H), 2.24 (s, 3H), 2.38 (s, 3H), 7.3–8.2 (m, 15H, 3x Benzoyl Ar-H)",
      "nmr13C": "δ 9.5, 14.8, 20.8, 21.8, 22.6, 26.8, 127.0–133.7 (aromatic cluster), 167.0, 170.4, 171.2, 172.7, 203.6 (C=O)"
    },
    "practicalApplications": [
      "First-line treatment of ovarian and metastatic breast carcinoma",
      "Advanced non-small cell lung cancer (NSCLC) therapy",
      "Drug-eluting coronary stents (prevents neo-intimal restenosis)"
    ],
    "atoms3D": [
      {
        "id": 0,
        "element": "C",
        "symbol": "C",
        "x": 0,
        "y": 0,
        "z": 0
      },
      {
        "id": 1,
        "element": "C",
        "symbol": "C",
        "x": 1.5,
        "y": 0.2,
        "z": 0
      },
      {
        "id": 2,
        "element": "C",
        "symbol": "C",
        "x": 2.1,
        "y": 1.5,
        "z": 0.5
      },
      {
        "id": 3,
        "element": "C",
        "symbol": "C",
        "x": 1.2,
        "y": 2.6,
        "z": 0.2
      },
      {
        "id": 4,
        "element": "C",
        "symbol": "C",
        "x": -0.3,
        "y": 2.4,
        "z": 0
      },
      {
        "id": 5,
        "element": "C",
        "symbol": "C",
        "x": -0.8,
        "y": 1.1,
        "z": -0.5
      },
      {
        "id": 6,
        "element": "O",
        "symbol": "O",
        "x": 3.4,
        "y": 1.6,
        "z": 0.3
      },
      {
        "id": 7,
        "element": "C",
        "symbol": "C",
        "x": 4.2,
        "y": 2.7,
        "z": 0.1
      },
      {
        "id": 8,
        "element": "O",
        "symbol": "O",
        "x": 3.8,
        "y": 3.8,
        "z": -0.3
      },
      {
        "id": 9,
        "element": "C",
        "symbol": "C",
        "x": 5.6,
        "y": 2.4,
        "z": 0.3
      },
      {
        "id": 10,
        "element": "N",
        "symbol": "N",
        "x": 6.2,
        "y": 1.2,
        "z": -0.2
      },
      {
        "id": 11,
        "element": "C",
        "symbol": "C",
        "x": 7.5,
        "y": 1,
        "z": -0.1
      },
      {
        "id": 12,
        "element": "O",
        "symbol": "O",
        "x": 8.2,
        "y": 1.9,
        "z": 0.4
      },
      {
        "id": 13,
        "element": "C",
        "symbol": "C",
        "x": -2.3,
        "y": 0.9,
        "z": -0.6
      },
      {
        "id": 14,
        "element": "O",
        "symbol": "O",
        "x": -2.8,
        "y": 1.8,
        "z": -1.3
      },
      {
        "id": 15,
        "element": "O",
        "symbol": "O",
        "x": -2.9,
        "y": -0.2,
        "z": -0.1
      },
      {
        "id": 16,
        "element": "C",
        "symbol": "C",
        "x": -4.3,
        "y": -0.3,
        "z": -0.2
      }
    ],
    "bonds3D": [
      {
        "source": 0,
        "target": 1,
        "order": 1
      },
      {
        "source": 1,
        "target": 2,
        "order": 1
      },
      {
        "source": 2,
        "target": 3,
        "order": 1
      },
      {
        "source": 3,
        "target": 4,
        "order": 1
      },
      {
        "source": 4,
        "target": 5,
        "order": 1
      },
      {
        "source": 5,
        "target": 0,
        "order": 1
      },
      {
        "source": 2,
        "target": 6,
        "order": 1
      },
      {
        "source": 6,
        "target": 7,
        "order": 1
      },
      {
        "source": 7,
        "target": 8,
        "order": 2
      },
      {
        "source": 7,
        "target": 9,
        "order": 1
      },
      {
        "source": 9,
        "target": 10,
        "order": 1
      },
      {
        "source": 10,
        "target": 11,
        "order": 1
      },
      {
        "source": 11,
        "target": 12,
        "order": 2
      },
      {
        "source": 5,
        "target": 13,
        "order": 1
      },
      {
        "source": 13,
        "target": 14,
        "order": 2
      },
      {
        "source": 13,
        "target": 15,
        "order": 1
      },
      {
        "source": 15,
        "target": 16,
        "order": 1
      }
    ]
  },
  {
    "id": "curcumin",
    "name": "Curcumin (Diferuloylmethane)",
    "iupacName": "(1E,6E)-1,7-bis(4-hydroxy-3-methoxyphenyl)hepta-1,6-diene-3,5-dione",
    "formula": "C21H20O6",
    "smiles": "COC1=C(C=CC(=C1)/C=C/C(=O)CC(=O)/C=C/C2=CC(=C(C=C2)O)OC)O",
    "inchiKey": "VFLGKKFCLCGOHY-UHFFFAOYSA-N",
    "casNumber": "458-37-7",
    "category": "Polyphenol / Natural Antioxidant",
    "description": "The principal natural curcuminoid of turmeric (Curcuma longa). Exists in keto-enol tautomeric equilibrium with strong antioxidant radical scavenging, anti-inflammatory NF-κB inhibition, and metal-chelating properties.",
    "properties": {
      "molecularWeight": 368.38,
      "logP": 3.29,
      "tpsa": 93.1,
      "hBondDonors": 2,
      "hBondAcceptors": 6,
      "rotatableBonds": 8,
      "heavyAtomCount": 27,
      "charge": 0,
      "solubility": "0.011 mg/mL in H2O at 25°C (readily soluble in ethanol, DMSO, and alkaline solutions)",
      "meltingPoint": "183 °C",
      "boilingPoint": "591 °C",
      "density": "1.30 g/cm³"
    },
    "lipinskiRuleOf5": {
      "passed": true,
      "violations": 0,
      "details": "Meets Lipinski criteria: MW 368.4 < 500, LogP 3.29 < 5, 2 H-Donors, 6 H-Acceptors. Note: Exhibits rapid systemic glucuronidation.",
      "mwPass": true,
      "logPPass": true,
      "donorsPass": true,
      "acceptorsPass": true
    },
    "pharmacology": {
      "mechanismOfAction": "Direct down-regulation of NF-κB transcription factor and suppression of inducible inflammatory enzymes COX-2 and 5-LOX; potent scavenger of hydroxyl, superoxide, and nitric oxide radicals.",
      "targetReceptors": [
        "IκB kinase (IKK)",
        "NF-κB p65 subunit",
        "Histone acetyltransferases (p300/CBP)",
        "AMPK activator"
      ],
      "bioavailability": "< 1% oral (enhanced 2000% by co-administration with piperine from black pepper)",
      "halfLife": "1.5 – 2.0 hours",
      "metabolism": "Rapid reduction to dihydrocurcumin and hexahydrocurcumin, followed by extensive glucuronide and sulfate conjugation in gut and liver.",
      "clearance": "Predominantly biliary and fecal excretion (> 90%)."
    },
    "safetyAndHazards": {
      "hazardLevel": "Low",
      "ghsPictograms": [],
      "ghsSignalWord": "Caution",
      "hazardStatements": [
        "H316: Causes mild skin irritation (rare)"
      ],
      "precautionaryMeasures": [
        "P264: Wash skin thoroughly after handling"
      ],
      "ppeRequired": [
        "Standard Lab Gloves",
        "Safety Eyewear"
      ],
      "disposalProtocol": "Normal non-hazardous organic laboratory waste."
    },
    "synthesisRoute": {
      "summary": "Condensation of acetylacetone with two equivalents of vanillin in the presence of boron trioxide (B2O3) to prevent Knoevenagel condensation at C3.",
      "greenChemistryScore": 84,
      "steps": [
        {
          "stepNumber": 1,
          "reactionName": "Boron Complexation",
          "reactants": [
            "Acetylacetone (Pentane-2,4-dione)",
            "Boron trioxide (B2O3)"
          ],
          "reagents": [
            "Ethyl acetate solvent"
          ],
          "conditions": "60°C for 30 minutes",
          "yield": "98%",
          "notes": "Boron complex protects the central methylene carbon."
        },
        {
          "stepNumber": 2,
          "reactionName": "Aldol Condensation with Vanillin",
          "reactants": [
            "Boron-acetylacetone complex",
            "Vanillin (4-hydroxy-3-methoxybenzaldehyde)"
          ],
          "reagents": [
            "Tributyl borate",
            "Butylamine catalyst"
          ],
          "conditions": "80°C for 4 hours",
          "yield": "82%",
          "notes": "Double aldol condensation at both terminal methyl groups."
        },
        {
          "stepNumber": 3,
          "reactionName": "Acid Hydrolysis",
          "reactants": [
            "Boron curcumin complex"
          ],
          "reagents": [
            "Dilute hydrochloric acid (0.5 M HCl)"
          ],
          "conditions": "80°C for 1 hour",
          "yield": "90%",
          "notes": "Hydrolyzes boron ester, precipitating brilliant orange curcumin crystals."
        }
      ]
    },
    "spectroscopy": {
      "irPeaks": [
        {
          "wavenumber": 3500,
          "intensity": "Broad",
          "bond": "O-H",
          "functionalGroup": "Phenolic hydroxyl"
        },
        {
          "wavenumber": 1628,
          "intensity": "Strong",
          "bond": "C=O",
          "functionalGroup": "Enolic conjugated carbonyl"
        },
        {
          "wavenumber": 1510,
          "intensity": "Strong",
          "bond": "C=C",
          "functionalGroup": "Aromatic & alkene skeleton"
        }
      ],
      "uvVisMax": "425 nm (in ethanol, vibrant yellow-orange absorption, ε = 55,000 M⁻¹cm⁻¹)",
      "nmr1H": "δ 3.85 (s, 6H, 2x O-CH3), 5.82 (s, 1H, =CH- enol), 6.55 (d, 2H, =CH-), 6.82 (d, 2H, Ar-H), 7.10 (d, 2H, Ar-H), 7.22 (s, 2H, Ar-H), 7.55 (d, 2H, =CH-), 9.6 (br s, 2H, OH)",
      "nmr13C": "δ 56.4 (2x OMe), 101.4 (C4), 111.8, 116.3, 122.2, 123.6, 128.1, 141.2, 148.6, 149.9, 183.8 (2x C=O)"
    },
    "practicalApplications": [
      "Nutraceutical formulation with enhanced bioavailability (nano-curcumin / piperine blends)",
      "Clinical research in osteoarthritic inflammatory management",
      "Natural food colorant (E100) and pH indicator"
    ],
    "atoms3D": [
      {
        "id": 0,
        "element": "C",
        "symbol": "C",
        "x": 0,
        "y": 0,
        "z": 0
      },
      {
        "id": 1,
        "element": "C",
        "symbol": "C",
        "x": 1.4,
        "y": 0,
        "z": 0
      },
      {
        "id": 2,
        "element": "C",
        "symbol": "C",
        "x": 2.1,
        "y": 1.2,
        "z": 0
      },
      {
        "id": 3,
        "element": "C",
        "symbol": "C",
        "x": 1.4,
        "y": 2.4,
        "z": 0
      },
      {
        "id": 4,
        "element": "C",
        "symbol": "C",
        "x": 0,
        "y": 2.4,
        "z": 0
      },
      {
        "id": 5,
        "element": "C",
        "symbol": "C",
        "x": -0.7,
        "y": 1.2,
        "z": 0
      },
      {
        "id": 6,
        "element": "O",
        "symbol": "O",
        "x": -2.05,
        "y": 1.2,
        "z": 0
      },
      {
        "id": 7,
        "element": "O",
        "symbol": "O",
        "x": -0.7,
        "y": 3.55,
        "z": 0
      },
      {
        "id": 8,
        "element": "C",
        "symbol": "C",
        "x": -0.1,
        "y": 4.8,
        "z": 0
      },
      {
        "id": 9,
        "element": "C",
        "symbol": "C",
        "x": 3.5,
        "y": 1.2,
        "z": 0
      },
      {
        "id": 10,
        "element": "C",
        "symbol": "C",
        "x": 4.3,
        "y": 2.3,
        "z": 0
      },
      {
        "id": 11,
        "element": "C",
        "symbol": "C",
        "x": 5.7,
        "y": 2.3,
        "z": 0
      },
      {
        "id": 12,
        "element": "O",
        "symbol": "O",
        "x": 6.4,
        "y": 1.2,
        "z": 0
      },
      {
        "id": 13,
        "element": "C",
        "symbol": "C",
        "x": 6.5,
        "y": 3.5,
        "z": 0
      }
    ],
    "bonds3D": [
      {
        "source": 0,
        "target": 1,
        "order": 2
      },
      {
        "source": 1,
        "target": 2,
        "order": 1
      },
      {
        "source": 2,
        "target": 3,
        "order": 2
      },
      {
        "source": 3,
        "target": 4,
        "order": 1
      },
      {
        "source": 4,
        "target": 5,
        "order": 2
      },
      {
        "source": 5,
        "target": 0,
        "order": 1
      },
      {
        "source": 5,
        "target": 6,
        "order": 1
      },
      {
        "source": 4,
        "target": 7,
        "order": 1
      },
      {
        "source": 7,
        "target": 8,
        "order": 1
      },
      {
        "source": 2,
        "target": 9,
        "order": 1
      },
      {
        "source": 9,
        "target": 10,
        "order": 2
      },
      {
        "source": 10,
        "target": 11,
        "order": 1
      },
      {
        "source": 11,
        "target": 12,
        "order": 2
      },
      {
        "source": 11,
        "target": 13,
        "order": 1
      }
    ]
  },
  {
    "id": "acetic_acid",
    "name": "Acetic Acid (Ethanoic Acid)",
    "iupacName": "Ethanoic acid",
    "formula": "C2H4O2",
    "smiles": "CC(=O)O",
    "inchiKey": "QTBSBXVTEAMEQO-UHFFFAOYSA-N",
    "casNumber": "64-19-7",
    "category": "Carboxylic Acid / Monocarboxylic Acid",
    "chemicalFamily": "acid",
    "functionalGroups": [
      "Carboxylic Acid (-COOH)",
      "Methyl (-CH3)"
    ],
    "acidBaseProfile": {
      "character": "Weak Acid",
      "pKa": 4.76,
      "conjugateSpecies": "Acetate ion (CH3COO⁻)"
    },
    "description": "A fundamental monocarboxylic acid giving vinegar its pungent odor and sour taste. Acts as a vital biochemical metabolic precursor for acetyl-CoA and a primary organic chemical building block for polyvinyl acetate and acetic anhydride.",
    "properties": {
      "molecularWeight": 60.05,
      "logP": -0.17,
      "tpsa": 37.3,
      "hBondDonors": 1,
      "hBondAcceptors": 2,
      "rotatableBonds": 0,
      "heavyAtomCount": 4,
      "charge": 0,
      "solubility": "Miscible in water in all proportions (1000 mg/mL)",
      "meltingPoint": "16.6 °C (glacial form freezes)",
      "boilingPoint": "117.9 °C",
      "density": "1.05 g/cm³"
    },
    "lipinskiRuleOf5": {
      "passed": true,
      "violations": 0,
      "details": "Small organic acid meeting all Lipinski criteria. Rapid cellular uptake and assimilation into the citric acid cycle.",
      "mwPass": true,
      "logPPass": true,
      "donorsPass": true,
      "acceptorsPass": true
    },
    "pharmacology": {
      "mechanismOfAction": "In biological systems, activated to acetyl-CoA by acetyl-CoA synthetase for entry into the Krebs cycle and fatty acid biosynthesis; topical antimicrobial action occurs by disrupting bacterial intracellular pH balance.",
      "targetReceptors": [
        "Acetyl-CoA Synthetase",
        "Free Fatty Acid Receptor 2 (FFAR2 / GPR43)",
        "FFAR3 (GPR41)"
      ],
      "bioavailability": "100% gastrointestinal absorption",
      "halfLife": "15 – 30 minutes in systemic circulation",
      "metabolism": "Rapid incorporation into central intermediary carbohydrate and lipid metabolism.",
      "clearance": "Expired as CO2 via lungs; trace renal excretion."
    },
    "safetyAndHazards": {
      "hazardLevel": "High",
      "ghsPictograms": [
        "GHS05_Corrosive",
        "GHS02_Flammable"
      ],
      "ghsSignalWord": "Danger",
      "hazardStatements": [
        "H226: Flammable liquid and vapor",
        "H314: Causes severe skin burns and serious eye damage"
      ],
      "precautionaryMeasures": [
        "P210: Keep away from heat, sparks, open flames",
        "P280: Wear protective gloves, protective clothing, eye and face protection",
        "P301+P330+P331: IF SWALLOWED: Rinse mouth. Do NOT induce vomiting"
      ],
      "ppeRequired": [
        "Neoprene or Butyl Rubber Gloves",
        "Face Shield with Chemical Splash Goggles",
        "Acid-Resistant Apron",
        "Fume Hood"
      ],
      "disposalProtocol": "Dilute slowly with cold water, neutralize with sodium carbonate or calcium hydroxide, and dispose of through regulated chemical effluent."
    },
    "synthesisRoute": {
      "summary": "Industrial Monsanto / Cativa carbonylation of methanol with carbon monoxide over rhodium or iridium catalyst; also produced biologically by Acetobacter fermentation of ethanol.",
      "greenChemistryScore": 92,
      "steps": [
        {
          "stepNumber": 1,
          "reactionName": "Cativa Methanol Carbonylation",
          "reactants": [
            "Methanol (CH3OH)",
            "Carbon monoxide (CO)"
          ],
          "reagents": [
            "Iridium catalyst [Ir(CO)2I2]⁻",
            "Ruthenium iodide promoter",
            "Methyl iodide"
          ],
          "conditions": "190°C, 30 bar pressure",
          "yield": "99%",
          "notes": "High atom economy (100% theoretical atom retention)."
        }
      ]
    },
    "spectroscopy": {
      "irPeaks": [
        {
          "wavenumber": 1715,
          "intensity": "Strong",
          "bond": "C=O",
          "functionalGroup": "Carboxylic acid carbonyl"
        },
        {
          "wavenumber": 3000,
          "intensity": "Broad",
          "bond": "O-H",
          "functionalGroup": "Carboxylic acid H-bonded hydroxyl (2500-3300 cm⁻¹)"
        },
        {
          "wavenumber": 1260,
          "intensity": "Strong",
          "bond": "C-O",
          "functionalGroup": "C-O single bond stretch"
        },
        {
          "wavenumber": 1410,
          "intensity": "Medium",
          "bond": "C-H",
          "functionalGroup": "Methyl bending"
        }
      ],
      "uvVisMax": "208 nm (n -> π* carbonyl transition)",
      "nmr1H": "δ 2.10 (s, 3H, CH3), 11.4 (br s, 1H, COOH)",
      "nmr13C": "δ 20.8 (CH3), 178.1 (C=O)"
    },
    "practicalApplications": [
      "Industrial monomer production for vinyl acetate monomer (VAM) and PET polyester",
      "Food preservation and condiment manufacturing (vinegar standard ~4-8%)",
      "Cervical screening via acetic acid visual inspection (VIA)",
      "Descaling and pH adjustment reagent in analytical laboratories"
    ],
    "atoms3D": [
      {
        "id": 0,
        "element": "C",
        "symbol": "C",
        "x": -1.35,
        "y": -0.15,
        "z": 0
      },
      {
        "id": 1,
        "element": "C",
        "symbol": "C",
        "x": 0.12,
        "y": 0.15,
        "z": 0
      },
      {
        "id": 2,
        "element": "O",
        "symbol": "O",
        "x": 0.65,
        "y": 1.25,
        "z": 0
      },
      {
        "id": 3,
        "element": "O",
        "symbol": "O",
        "x": 0.85,
        "y": -0.98,
        "z": 0
      },
      {
        "id": 4,
        "element": "H",
        "symbol": "H",
        "x": 1.82,
        "y": -0.85,
        "z": 0
      },
      {
        "id": 5,
        "element": "H",
        "symbol": "H",
        "x": -1.65,
        "y": -1.18,
        "z": 0
      },
      {
        "id": 6,
        "element": "H",
        "symbol": "H",
        "x": -1.75,
        "y": 0.35,
        "z": 0.88
      },
      {
        "id": 7,
        "element": "H",
        "symbol": "H",
        "x": -1.75,
        "y": 0.35,
        "z": -0.88
      }
    ],
    "bonds3D": [
      {
        "source": 0,
        "target": 1,
        "order": 1
      },
      {
        "source": 1,
        "target": 2,
        "order": 2
      },
      {
        "source": 1,
        "target": 3,
        "order": 1
      },
      {
        "source": 3,
        "target": 4,
        "order": 1
      },
      {
        "source": 0,
        "target": 5,
        "order": 1
      },
      {
        "source": 0,
        "target": 6,
        "order": 1
      },
      {
        "source": 0,
        "target": 7,
        "order": 1
      }
    ]
  },
  {
    "id": "citric_acid",
    "name": "Citric Acid",
    "iupacName": "2-Hydroxypropane-1,2,3-tricarboxylic acid",
    "formula": "C6H8O7",
    "smiles": "C(C(=O)O)C(CC(=O)O)(C(=O)O)O",
    "inchiKey": "KRKNYBCHXYNGOX-UHFFFAOYSA-N",
    "casNumber": "77-92-9",
    "category": "Polycarboxylic Acid / Hydroxy Acid",
    "chemicalFamily": "acid",
    "functionalGroups": [
      "Carboxylic Acid (-COOH, 3x)",
      "Tertiary Alcohol (-OH)"
    ],
    "acidBaseProfile": {
      "character": "Weak Acid",
      "pKa": 3.13,
      "conjugateSpecies": "Citrate trianion (C6H5O7³⁻)"
    },
    "description": "A natural tricarboxylic hydroxy acid that is a central intermediate in cellular aerobic respiration (Krebs cycle). Acts as a natural preservative, chelating agent, and acidulant in pharmaceuticals and foods.",
    "properties": {
      "molecularWeight": 192.12,
      "logP": -1.72,
      "tpsa": 132.1,
      "hBondDonors": 4,
      "hBondAcceptors": 7,
      "rotatableBonds": 3,
      "heavyAtomCount": 13,
      "charge": 0,
      "solubility": "592 mg/mL in H2O at 20°C",
      "meltingPoint": "153 °C",
      "boilingPoint": "175 °C (decomposes)",
      "density": "1.66 g/cm³"
    },
    "lipinskiRuleOf5": {
      "passed": true,
      "violations": 0,
      "details": "Conforms to Lipinski Rule of 5: MW 192.1 < 500, LogP -1.72 < 5, Donors 4 <= 5, Acceptors 7 <= 10.",
      "mwPass": true,
      "logPPass": true,
      "donorsPass": true,
      "acceptorsPass": true
    },
    "pharmacology": {
      "mechanismOfAction": "Enzymatically isomerized to isocitrate by aconitase in the mitochondria; systemic alkalinizer through hepatic oxidation yielding potassium bicarbonate; chelates ionized calcium, preventing nephrolithiasis and coagulation.",
      "targetReceptors": [
        "Aconitase enzyme",
        "Calcium cation chelation",
        "Sodium-dicarboxylate cotransporter (NaDC1)"
      ],
      "bioavailability": "Extensively absorbed and metabolized; < 1% excreted unchanged in urine.",
      "halfLife": "Endogenous metabolic turnover ~10-20 minutes",
      "metabolism": "Rapid oxidation through the mitochondrial Krebs tricarboxylic acid cycle.",
      "clearance": "Metabolized to carbon dioxide and water; small fraction excreted renally."
    },
    "safetyAndHazards": {
      "hazardLevel": "Low",
      "ghsPictograms": [
        "GHS07_Harmful"
      ],
      "ghsSignalWord": "Warning",
      "hazardStatements": [
        "H319: Causes serious eye irritation",
        "H335: May cause respiratory irritation"
      ],
      "precautionaryMeasures": [
        "P280: Wear eye protection",
        "P305+P351+P338: IF IN EYES: Rinse cautiously with water"
      ],
      "ppeRequired": [
        "Nitrile Gloves",
        "Safety Eyewear"
      ],
      "disposalProtocol": "Normal aqueous non-hazardous laboratory drain disposal with high water dilution."
    },
    "synthesisRoute": {
      "summary": "Industrial submerged aerobic fermentation of glucose/molasses using Aspergillus niger mold, followed by calcium hydroxide precipitation and sulfuric acid release.",
      "greenChemistryScore": 94,
      "steps": [
        {
          "stepNumber": 1,
          "reactionName": "Biotechnological Fermentation",
          "reactants": [
            "Glucose / Sucrose",
            "Oxygen"
          ],
          "reagents": [
            "Aspergillus niger microbial strain"
          ],
          "conditions": "30°C, aerated fermentation tank for 5-8 days",
          "yield": "85-90% based on sugar consumed",
          "notes": "High conversion efficiency from renewable biomass."
        }
      ]
    },
    "spectroscopy": {
      "irPeaks": [
        {
          "wavenumber": 1750,
          "intensity": "Strong",
          "bond": "C=O",
          "functionalGroup": "Central carboxylic carbonyl"
        },
        {
          "wavenumber": 1705,
          "intensity": "Strong",
          "bond": "C=O",
          "functionalGroup": "Terminal carboxyl carbonyls"
        },
        {
          "wavenumber": 3495,
          "intensity": "Medium",
          "bond": "O-H",
          "functionalGroup": "Alcoholic hydroxyl"
        },
        {
          "wavenumber": 3200,
          "intensity": "Broad",
          "bond": "O-H",
          "functionalGroup": "Carboxylic acid O-H envelope"
        }
      ],
      "uvVisMax": "210 nm",
      "nmr1H": "δ 2.82 (d, 2H, CH2), 2.98 (d, 2H, CH2), 4.8 (br s, 4H, OH/COOH)",
      "nmr13C": "δ 43.2 (2x CH2), 73.4 (C-OH quaternary), 171.5 (2x terminal COOH), 175.0 (central COOH)"
    },
    "practicalApplications": [
      "Anticoagulant in blood transfusion tubes (citrate chelates calcium required for clotting)",
      "Dissolution of kidney stones and prevention of nephrolithiasis",
      "Food and beverage acidulant (E330) and antioxidant synergist"
    ],
    "atoms3D": [
      {
        "id": 0,
        "element": "C",
        "symbol": "C",
        "x": 0,
        "y": 0,
        "z": 0
      },
      {
        "id": 1,
        "element": "C",
        "symbol": "C",
        "x": -1.3,
        "y": 0.8,
        "z": 0
      },
      {
        "id": 2,
        "element": "C",
        "symbol": "C",
        "x": 1.3,
        "y": 0.8,
        "z": 0
      },
      {
        "id": 3,
        "element": "O",
        "symbol": "O",
        "x": 0,
        "y": -0.8,
        "z": 1.2
      },
      {
        "id": 4,
        "element": "C",
        "symbol": "C",
        "x": 0,
        "y": -0.9,
        "z": -1.2
      },
      {
        "id": 5,
        "element": "O",
        "symbol": "O",
        "x": -0.8,
        "y": -0.9,
        "z": -2.1
      },
      {
        "id": 6,
        "element": "O",
        "symbol": "O",
        "x": 1.1,
        "y": -1.6,
        "z": -1.2
      },
      {
        "id": 7,
        "element": "C",
        "symbol": "C",
        "x": -2.6,
        "y": 0,
        "z": 0
      },
      {
        "id": 8,
        "element": "O",
        "symbol": "O",
        "x": -3.6,
        "y": 0.6,
        "z": 0
      },
      {
        "id": 9,
        "element": "O",
        "symbol": "O",
        "x": -2.6,
        "y": -1.3,
        "z": 0
      },
      {
        "id": 10,
        "element": "C",
        "symbol": "C",
        "x": 2.6,
        "y": 0,
        "z": 0
      },
      {
        "id": 11,
        "element": "O",
        "symbol": "O",
        "x": 3.6,
        "y": 0.6,
        "z": 0
      },
      {
        "id": 12,
        "element": "O",
        "symbol": "O",
        "x": 2.6,
        "y": -1.3,
        "z": 0
      }
    ],
    "bonds3D": [
      {
        "source": 0,
        "target": 1,
        "order": 1
      },
      {
        "source": 0,
        "target": 2,
        "order": 1
      },
      {
        "source": 0,
        "target": 3,
        "order": 1
      },
      {
        "source": 0,
        "target": 4,
        "order": 1
      },
      {
        "source": 4,
        "target": 5,
        "order": 2
      },
      {
        "source": 4,
        "target": 6,
        "order": 1
      },
      {
        "source": 1,
        "target": 7,
        "order": 1
      },
      {
        "source": 7,
        "target": 8,
        "order": 2
      },
      {
        "source": 7,
        "target": 9,
        "order": 1
      },
      {
        "source": 2,
        "target": 10,
        "order": 1
      },
      {
        "source": 10,
        "target": 11,
        "order": 2
      },
      {
        "source": 10,
        "target": 12,
        "order": 1
      }
    ]
  },
  {
    "id": "pyridine",
    "name": "Pyridine",
    "iupacName": "Pyridine",
    "formula": "C5H5N",
    "smiles": "C1=CC=NC=C1",
    "inchiKey": "JUJWROOIHBZHMG-UHFFFAOYSA-N",
    "casNumber": "110-86-1",
    "category": "Heterocyclic Organic Base / Azine",
    "chemicalFamily": "base",
    "functionalGroups": [
      "Pyridine Ring",
      "Tertiary Aromatic Amine (=N-)"
    ],
    "acidBaseProfile": {
      "character": "Weak Base",
      "pKb": 8.75,
      "pKa": 5.25,
      "conjugateSpecies": "Pyridinium ion (C5H5NH⁺)"
    },
    "description": "A basic heterocyclic organic compound with the chemical formula C5H5N. Structurally related to benzene, with one methine group (=CH-) replaced by a nitrogen atom. A crucial polar basic solvent and reagent in organic synthesis and pharmaceuticals.",
    "properties": {
      "molecularWeight": 79.1,
      "logP": 0.65,
      "tpsa": 12.9,
      "hBondDonors": 0,
      "hBondAcceptors": 1,
      "rotatableBonds": 0,
      "heavyAtomCount": 6,
      "charge": 0,
      "solubility": "Miscible with water, ethanol, and diethyl ether in all proportions",
      "meltingPoint": "-41.6 °C",
      "boilingPoint": "115.2 °C",
      "density": "0.982 g/cm³"
    },
    "lipinskiRuleOf5": {
      "passed": true,
      "violations": 0,
      "details": "Small aromatic heterocyclic base meeting all Lipinski criteria. High membrane diffusion and tissue penetration.",
      "mwPass": true,
      "logPPass": true,
      "donorsPass": true,
      "acceptorsPass": true
    },
    "pharmacology": {
      "mechanismOfAction": "Acts as a nucleophilic base and hydrogen bond acceptor; toxicological mechanism involves central nervous system depression, irritation of mucosal linings, and reversible inhibition of hepatic mixed-function oxidases.",
      "targetReceptors": [
        "Nicotinic Acetylcholine Receptors (partial affinity)",
        "Cytochrome P450 enzymes (inhibitor)"
      ],
      "bioavailability": "Readily absorbed via inhalation, ingestion, and dermal absorption.",
      "halfLife": "5 – 8 hours in humans",
      "metabolism": "Hepatic N-methylation to N-methylpyridinium and N-oxidation by CYP2E1.",
      "clearance": "Renal excretion of conjugated metabolites."
    },
    "safetyAndHazards": {
      "hazardLevel": "High",
      "ghsPictograms": [
        "GHS02_Flammable",
        "GHS07_Harmful"
      ],
      "ghsSignalWord": "Danger",
      "hazardStatements": [
        "H225: Highly flammable liquid and vapor",
        "H302+H312+H332: Harmful if swallowed, in contact with skin or if inhaled",
        "H319: Causes serious eye irritation"
      ],
      "precautionaryMeasures": [
        "P210: Keep away from open sparks and flames",
        "P280: Wear protective gloves and eye protection",
        "P304+P340: IF INHALED: Remove person to fresh air"
      ],
      "ppeRequired": [
        "Butyl Rubber Gloves (Nitrile is permeable to pyridine)",
        "Splash Goggles",
        "Chemical Fume Hood"
      ],
      "disposalProtocol": "Collect in non-halogenated flammable solvent waste for high-temperature incineration."
    },
    "synthesisRoute": {
      "summary": "Industrial Chichibabin pyridine synthesis from acetaldehyde, formaldehyde, and ammonia over a solid acid catalyst at 400°C.",
      "greenChemistryScore": 82,
      "steps": [
        {
          "stepNumber": 1,
          "reactionName": "Chichibabin Condensation",
          "reactants": [
            "Acetaldehyde (CH3CHO)",
            "Formaldehyde (HCHO)",
            "Ammonia (NH3)"
          ],
          "reagents": [
            "Silica-alumina or zeolite catalyst"
          ],
          "conditions": "400–450°C in gas phase tubular reactor",
          "yield": "72%",
          "notes": "Produces pyridine and 3-methylpyridine; fractionally distilled."
        }
      ]
    },
    "spectroscopy": {
      "irPeaks": [
        {
          "wavenumber": 3030,
          "intensity": "Medium",
          "bond": "C-H",
          "functionalGroup": "Aromatic C-H stretch"
        },
        {
          "wavenumber": 1580,
          "intensity": "Strong",
          "bond": "C=N / C=C",
          "functionalGroup": "Pyridine ring quadrant stretch"
        },
        {
          "wavenumber": 1440,
          "intensity": "Strong",
          "bond": "C=C / C-N",
          "functionalGroup": "Ring semicircle stretch"
        },
        {
          "wavenumber": 700,
          "intensity": "Strong",
          "bond": "C-H",
          "functionalGroup": "Out-of-plane ring bending"
        }
      ],
      "uvVisMax": "256 nm (in ethanol, ε = 2,000 M⁻¹cm⁻¹)",
      "nmr1H": "δ 7.25 (m, 2H, β-H), 7.64 (m, 1H, γ-H), 8.59 (d, 2H, α-H adjacent to nitrogen)",
      "nmr13C": "δ 123.6 (2x C-β), 135.8 (C-γ), 149.8 (2x C-α)"
    },
    "practicalApplications": [
      "Precursor for agricultural chemicals: paraquat and diquat herbicides",
      "Key intermediate in pharmaceuticals (sulfapyridine, tripelennamine, piroxicam)",
      "Base and solvent in esterification and acylation reactions",
      "Denaturant for industrial ethanol blends"
    ],
    "atoms3D": [
      {
        "id": 0,
        "element": "N",
        "symbol": "N",
        "x": 0,
        "y": 1.4,
        "z": 0
      },
      {
        "id": 1,
        "element": "C",
        "symbol": "C",
        "x": 1.2,
        "y": 0.7,
        "z": 0
      },
      {
        "id": 2,
        "element": "C",
        "symbol": "C",
        "x": 1.2,
        "y": -0.7,
        "z": 0
      },
      {
        "id": 3,
        "element": "C",
        "symbol": "C",
        "x": 0,
        "y": -1.4,
        "z": 0
      },
      {
        "id": 4,
        "element": "C",
        "symbol": "C",
        "x": -1.2,
        "y": -0.7,
        "z": 0
      },
      {
        "id": 5,
        "element": "C",
        "symbol": "C",
        "x": -1.2,
        "y": 0.7,
        "z": 0
      },
      {
        "id": 6,
        "element": "H",
        "symbol": "H",
        "x": 2.14,
        "y": 1.25,
        "z": 0
      },
      {
        "id": 7,
        "element": "H",
        "symbol": "H",
        "x": 2.14,
        "y": -1.25,
        "z": 0
      },
      {
        "id": 8,
        "element": "H",
        "symbol": "H",
        "x": 0,
        "y": -2.48,
        "z": 0
      },
      {
        "id": 9,
        "element": "H",
        "symbol": "H",
        "x": -2.14,
        "y": -1.25,
        "z": 0
      },
      {
        "id": 10,
        "element": "H",
        "symbol": "H",
        "x": -2.14,
        "y": 1.25,
        "z": 0
      }
    ],
    "bonds3D": [
      {
        "source": 0,
        "target": 1,
        "order": 2
      },
      {
        "source": 1,
        "target": 2,
        "order": 1
      },
      {
        "source": 2,
        "target": 3,
        "order": 2
      },
      {
        "source": 3,
        "target": 4,
        "order": 1
      },
      {
        "source": 4,
        "target": 5,
        "order": 2
      },
      {
        "source": 5,
        "target": 0,
        "order": 1
      },
      {
        "source": 1,
        "target": 6,
        "order": 1
      },
      {
        "source": 2,
        "target": 7,
        "order": 1
      },
      {
        "source": 3,
        "target": 8,
        "order": 1
      },
      {
        "source": 4,
        "target": 9,
        "order": 1
      },
      {
        "source": 5,
        "target": 10,
        "order": 1
      }
    ]
  },
  {
    "id": "ammonia",
    "name": "Ammonia",
    "iupacName": "Azane",
    "formula": "NH3",
    "smiles": "N",
    "inchiKey": "QGZKDVFQNNGYKY-UHFFFAOYSA-N",
    "casNumber": "7664-41-7",
    "category": "Inorganic Base / Pnictogen Hydride",
    "chemicalFamily": "base",
    "functionalGroups": [
      "Amine / Azane (-NH3)"
    ],
    "acidBaseProfile": {
      "character": "Weak Base",
      "pKb": 4.75,
      "pKa": 9.25,
      "conjugateSpecies": "Ammonium cation (NH4⁺)"
    },
    "description": "An inorganic compound of nitrogen and hydrogen with the formula NH3. A colorless gas with a characteristic pungent smell. A vital chemical feedstock for fertilizers and synthesis of nitrogenous chemicals.",
    "properties": {
      "molecularWeight": 17.03,
      "logP": -0.64,
      "tpsa": 1,
      "hBondDonors": 3,
      "hBondAcceptors": 1,
      "rotatableBonds": 0,
      "heavyAtomCount": 1,
      "charge": 0,
      "solubility": "47% w/w in water at 0°C (extremely soluble)",
      "meltingPoint": "-77.7 °C",
      "boilingPoint": "-33.3 °C",
      "density": "0.73 kg/m³ (gas)"
    },
    "lipinskiRuleOf5": {
      "passed": true,
      "violations": 0,
      "details": "Small gas molecule. High diffusibility across biological membranes.",
      "mwPass": true,
      "logPPass": true,
      "donorsPass": true,
      "acceptorsPass": true
    },
    "pharmacology": {
      "mechanismOfAction": "In biological systems, converted to urea via the hepatic ornithine cycle; neurotoxicity in hyperammonemia results from astrocyte swelling due to glutamine accumulation and NMDA receptor activation.",
      "targetReceptors": [
        "Carbamoyl Phosphate Synthetase I",
        "Glutamine Synthetase",
        "NMDA receptors"
      ],
      "bioavailability": "Rapidly absorbed via respiratory epithelium and GI tract.",
      "halfLife": "Few minutes in bloodstream (rapidly captured by liver into urea cycle)",
      "metabolism": "Hepatic urea cycle conversion to non-toxic urea.",
      "clearance": "Renal excretion of urea (85%) and ammonium ion."
    },
    "safetyAndHazards": {
      "hazardLevel": "High",
      "ghsPictograms": [
        "GHS05_Corrosive",
        "GHS06_Toxic",
        "GHS09_Environmental"
      ],
      "ghsSignalWord": "Danger",
      "hazardStatements": [
        "H314: Causes severe skin burns and eye damage",
        "H331: Toxic if inhaled",
        "H400: Very toxic to aquatic life"
      ],
      "precautionaryMeasures": [
        "P260: Do not breathe dust/fume/gas/mist",
        "P280: Wear protective gloves/clothing/eye protection"
      ],
      "ppeRequired": [
        "Full Facepiece Chemical Respirator",
        "Heavy-Duty Nitrile or Neoprene Gloves",
        "Splash Suit"
      ],
      "disposalProtocol": "Neutralize slowly with dilute hydrochloric or sulfuric acid to form ammonium salt before discharge."
    },
    "synthesisRoute": {
      "summary": "Haber-Bosch process directly synthesizing ammonia from atmospheric nitrogen and hydrogen gas over an iron-potassium-aluminum catalyst at high temperature and pressure.",
      "greenChemistryScore": 85,
      "steps": [
        {
          "stepNumber": 1,
          "reactionName": "Haber-Bosch Synthesis",
          "reactants": [
            "Nitrogen gas (N2)",
            "Hydrogen gas (H2)"
          ],
          "reagents": [
            "Magnetite (Fe3O4) catalyst promoted with K2O, CaO, Al2O3"
          ],
          "conditions": "400–450°C, 150–250 bar pressure",
          "yield": "15% per pass (recycled for 97% overall conversion)",
          "notes": "N2 + 3 H2 ⇌ 2 NH3 (exothermic reaction)."
        }
      ]
    },
    "spectroscopy": {
      "irPeaks": [
        {
          "wavenumber": 3335,
          "intensity": "Strong",
          "bond": "N-H",
          "functionalGroup": "Asymmetric N-H stretch"
        },
        {
          "wavenumber": 3414,
          "intensity": "Medium",
          "bond": "N-H",
          "functionalGroup": "Symmetric N-H stretch"
        },
        {
          "wavenumber": 1625,
          "intensity": "Strong",
          "bond": "H-N-H",
          "functionalGroup": "Degenerate bending vibration"
        }
      ],
      "uvVisMax": "194 nm",
      "nmr1H": "δ 0.6–1.5 (broad singlet in CDCl3)",
      "nmr13C": "N/A (No Carbon atoms)"
    },
    "practicalApplications": [
      "Fertilizer manufacturing (88% of global production: ammonium nitrate, urea, ammonium phosphate)",
      "Refrigeration gas (R-717) for industrial cold storage systems",
      "Purification of NOx emissions in SCR catalytic converter systems"
    ],
    "atoms3D": [
      {
        "id": 0,
        "element": "N",
        "symbol": "N",
        "x": 0,
        "y": 0,
        "z": 0.38
      },
      {
        "id": 1,
        "element": "H",
        "symbol": "H",
        "x": 0,
        "y": 0.94,
        "z": -0.13
      },
      {
        "id": 2,
        "element": "H",
        "symbol": "H",
        "x": 0.81,
        "y": -0.47,
        "z": -0.13
      },
      {
        "id": 3,
        "element": "H",
        "symbol": "H",
        "x": -0.81,
        "y": -0.47,
        "z": -0.13
      }
    ],
    "bonds3D": [
      {
        "source": 0,
        "target": 1,
        "order": 1
      },
      {
        "source": 0,
        "target": 2,
        "order": 1
      },
      {
        "source": 0,
        "target": 3,
        "order": 1
      }
    ]
  },
  {
    "id": "ethanol",
    "name": "Ethanol (Ethyl Alcohol)",
    "iupacName": "Ethanol",
    "formula": "C2H6O",
    "smiles": "CCO",
    "inchiKey": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
    "casNumber": "64-17-5",
    "category": "Primary Aliphatic Alcohol",
    "chemicalFamily": "alcohol",
    "functionalGroups": [
      "Primary Alcohol (-OH)",
      "Ethyl (-CH2CH3)"
    ],
    "acidBaseProfile": {
      "character": "Neutral",
      "pKa": 15.9,
      "conjugateSpecies": "Ethoxide anion (CH3CH2O⁻)"
    },
    "description": "A volatile, flammable, colorless liquid with a characteristic pleasant wine-like odor. Serves as a psychoactive recreational beverage agent, universal organic chemical solvent, antibacterial disinfectant, and biofuel additive.",
    "properties": {
      "molecularWeight": 46.07,
      "logP": -0.31,
      "tpsa": 20.2,
      "hBondDonors": 1,
      "hBondAcceptors": 1,
      "rotatableBonds": 0,
      "heavyAtomCount": 3,
      "charge": 0,
      "solubility": "Completely miscible with water in all proportions",
      "meltingPoint": "-114.1 °C",
      "boilingPoint": "78.2 °C",
      "density": "0.789 g/cm³"
    },
    "lipinskiRuleOf5": {
      "passed": true,
      "violations": 0,
      "details": "Meets all Lipinski criteria. Rapid passive diffusion across gastric and blood-brain barriers.",
      "mwPass": true,
      "logPPass": true,
      "donorsPass": true,
      "acceptorsPass": true
    },
    "pharmacology": {
      "mechanismOfAction": "Positive allosteric modulator of GABAA receptors enhancing inhibitory chloride flux; negative allosteric modulator of NMDA glutamate receptors; stimulates dopamine release in the mesolimbic reward pathway.",
      "targetReceptors": [
        "GABAA Receptor (Allosteric site)",
        "NMDA Receptor (GluN1/GluN2B)",
        "Glycine receptors",
        "Voltage-gated calcium channels"
      ],
      "bioavailability": "80–90% oral absorption (rapidly absorbed from stomach and upper small intestine)",
      "halfLife": "Zero-order elimination kinetics at typical blood concentrations (~15-20 mg/dL/hour)",
      "metabolism": "Sequential hepatic oxidation: alcohol dehydrogenase (ADH) oxidizes to toxic acetaldehyde, then aldehyde dehydrogenase (ALDH2) converts it to acetate.",
      "clearance": "90–98% hepatic oxidation; 2–10% excreted unchanged in breath, urine, and sweat."
    },
    "safetyAndHazards": {
      "hazardLevel": "Moderate",
      "ghsPictograms": [
        "GHS02_Flammable",
        "GHS07_Harmful"
      ],
      "ghsSignalWord": "Danger",
      "hazardStatements": [
        "H225: Highly flammable liquid and vapor",
        "H319: Causes serious eye irritation"
      ],
      "precautionaryMeasures": [
        "P210: Keep away from heat, sparks, open flames",
        "P233: Keep container tightly closed"
      ],
      "ppeRequired": [
        "Standard Nitrile Gloves",
        "Safety Eyewear"
      ],
      "disposalProtocol": "Normal solvent collection or high dilution drain disposal where local environmental rules permit."
    },
    "synthesisRoute": {
      "summary": "Biochemical fermentation of sugar/starch biomass using Saccharomyces cerevisiae yeast, or catalytic hydration of ethylene in the petrochemical industry.",
      "greenChemistryScore": 95,
      "steps": [
        {
          "stepNumber": 1,
          "reactionName": "Petrochemical Hydration / Fermentation",
          "reactants": [
            "Ethylene (H2C=CH2)",
            "Steam (H2O)"
          ],
          "reagents": [
            "Phosphoric acid (H3PO4) on silica support"
          ],
          "conditions": "300°C, 60–70 bar pressure",
          "yield": "95%",
          "notes": "Electrophilic addition of water across double bond produces industrial grade ethanol."
        }
      ]
    },
    "spectroscopy": {
      "irPeaks": [
        {
          "wavenumber": 3350,
          "intensity": "Broad",
          "bond": "O-H",
          "functionalGroup": "Intermolecularly H-bonded hydroxyl"
        },
        {
          "wavenumber": 2975,
          "intensity": "Strong",
          "bond": "C-H",
          "functionalGroup": "Aliphatic alkyl stretch"
        },
        {
          "wavenumber": 1050,
          "intensity": "Strong",
          "bond": "C-O",
          "functionalGroup": "Primary alcohol C-O stretching"
        }
      ],
      "uvVisMax": "Transparent above 205 nm (UV cutoff 205 nm, ideal spectroscopic solvent)",
      "nmr1H": "δ 1.22 (t, 3H, CH3), 2.61 (br s, 1H, OH), 3.68 (q, 2H, CH2)",
      "nmr13C": "δ 18.2 (CH3), 58.2 (CH2-OH)"
    },
    "practicalApplications": [
      "Universal chemical extraction and synthesis solvent",
      "Antiseptic hand sanitizers and skin disinfectant (60-80% aqueous v/v)",
      "Automotive fuel oxygenate additive (E10, E85 bioethanol)",
      "Recreational beverages and pharmaceutical tinctures"
    ],
    "atoms3D": [
      {
        "id": 0,
        "element": "C",
        "symbol": "C",
        "x": -1.22,
        "y": -0.22,
        "z": 0
      },
      {
        "id": 1,
        "element": "C",
        "symbol": "C",
        "x": 0.08,
        "y": 0.55,
        "z": 0
      },
      {
        "id": 2,
        "element": "O",
        "symbol": "O",
        "x": 1.22,
        "y": -0.28,
        "z": 0
      },
      {
        "id": 3,
        "element": "H",
        "symbol": "H",
        "x": 1.98,
        "y": 0.28,
        "z": 0
      },
      {
        "id": 4,
        "element": "H",
        "symbol": "H",
        "x": 0.12,
        "y": 1.22,
        "z": 0.88
      },
      {
        "id": 5,
        "element": "H",
        "symbol": "H",
        "x": 0.12,
        "y": 1.22,
        "z": -0.88
      },
      {
        "id": 6,
        "element": "H",
        "symbol": "H",
        "x": -1.25,
        "y": -0.88,
        "z": 0.88
      },
      {
        "id": 7,
        "element": "H",
        "symbol": "H",
        "x": -1.25,
        "y": -0.88,
        "z": -0.88
      },
      {
        "id": 8,
        "element": "H",
        "symbol": "H",
        "x": -2.08,
        "y": 0.45,
        "z": 0
      }
    ],
    "bonds3D": [
      {
        "source": 0,
        "target": 1,
        "order": 1
      },
      {
        "source": 1,
        "target": 2,
        "order": 1
      },
      {
        "source": 2,
        "target": 3,
        "order": 1
      },
      {
        "source": 1,
        "target": 4,
        "order": 1
      },
      {
        "source": 1,
        "target": 5,
        "order": 1
      },
      {
        "source": 0,
        "target": 6,
        "order": 1
      },
      {
        "source": 0,
        "target": 7,
        "order": 1
      },
      {
        "source": 0,
        "target": 8,
        "order": 1
      }
    ]
  },
  {
    "id": "acetone",
    "name": "Acetone (Propan-2-one)",
    "iupacName": "Propan-2-one",
    "formula": "C3H6O",
    "smiles": "CC(=O)C",
    "inchiKey": "CSCPPACGZOOCGX-UHFFFAOYSA-N",
    "casNumber": "67-64-1",
    "category": "Aliphatic Ketone / Dialkyl Ketone",
    "chemicalFamily": "ketone",
    "functionalGroups": [
      "Ketone Carbonyl (C=O)",
      "Methyl (-CH3, 2x)"
    ],
    "acidBaseProfile": {
      "character": "Neutral",
      "pKa": 19.3,
      "conjugateSpecies": "Acetone enolate (CH2=C(O⁻)CH3)"
    },
    "description": "The simplest and most important aliphatic ketone. A volatile, colorless, highly flammable liquid with a characteristic sweet, pungent odor. Widely used as a polar aprotic solvent in laboratories and industry.",
    "properties": {
      "molecularWeight": 58.08,
      "logP": -0.24,
      "tpsa": 17.1,
      "hBondDonors": 0,
      "hBondAcceptors": 1,
      "rotatableBonds": 0,
      "heavyAtomCount": 4,
      "charge": 0,
      "solubility": "Miscible with water, ethanol, and diethyl ether",
      "meltingPoint": "-94.7 °C",
      "boilingPoint": "56.05 °C",
      "density": "0.784 g/cm³"
    },
    "lipinskiRuleOf5": {
      "passed": true,
      "violations": 0,
      "details": "Meets all Lipinski criteria. High volatility and rapid biological clearance.",
      "mwPass": true,
      "logPPass": true,
      "donorsPass": true,
      "acceptorsPass": true
    },
    "pharmacology": {
      "mechanismOfAction": "In human metabolism, produced as an endogenous ketone body via acetoacetate decarboxylation in ketosis/ketoacidosis; acts as a mild central nervous system depressant at high occupational exposure levels.",
      "targetReceptors": [
        "GABAA receptor (weak enhancement)",
        "Cytochrome P450 2E1 (substrate and inducer)"
      ],
      "bioavailability": "High alveolar absorption via inhalation (70-80%) and 100% gastrointestinal absorption.",
      "halfLife": "19 – 31 hours in human tissues",
      "metabolism": "Oxidized by hepatic CYP2E1 to acetol and methylglyoxal, feeding into gluconeogenesis.",
      "clearance": "Exhaled unchanged via lungs (50–70%); remainder metabolized or excreted in urine."
    },
    "safetyAndHazards": {
      "hazardLevel": "Moderate",
      "ghsPictograms": [
        "GHS02_Flammable",
        "GHS07_Harmful"
      ],
      "ghsSignalWord": "Danger",
      "hazardStatements": [
        "H225: Highly flammable liquid and vapor",
        "H319: Causes serious eye irritation",
        "H336: May cause drowsiness or dizziness"
      ],
      "precautionaryMeasures": [
        "P210: Keep away from open sparks, hot surfaces and flames",
        "P261: Avoid breathing vapor or spray"
      ],
      "ppeRequired": [
        "Butyl Rubber Gloves (Nitrile is degraded rapidly by acetone)",
        "Splash Goggles",
        "Chemical Fume Hood"
      ],
      "disposalProtocol": "Collect in dedicated non-halogenated organic solvent waste stream."
    },
    "synthesisRoute": {
      "summary": "Industrial Cumene process (Hock process): cumene (isopropylbenzene) is autoxidized to cumene hydroperoxide, which undergoes acid-catalyzed cleavage into phenol and acetone.",
      "greenChemistryScore": 91,
      "steps": [
        {
          "stepNumber": 1,
          "reactionName": "Cumene Autoxidation & Hock Cleavage",
          "reactants": [
            "Cumene",
            "Oxygen (O2)"
          ],
          "reagents": [
            "Sulfuric acid catalyst"
          ],
          "conditions": "100°C air oxidation followed by 70°C acid cleavage",
          "yield": "93%",
          "notes": "Co-produces phenol and acetone in an efficient 1:1 equimolar ratio."
        }
      ]
    },
    "spectroscopy": {
      "irPeaks": [
        {
          "wavenumber": 1715,
          "intensity": "Strong",
          "bond": "C=O",
          "functionalGroup": "Dialkyl ketone carbonyl stretch"
        },
        {
          "wavenumber": 1365,
          "intensity": "Medium",
          "bond": "C-H",
          "functionalGroup": "Methyl symmetric deformation (CH3-CO)"
        },
        {
          "wavenumber": 1220,
          "intensity": "Strong",
          "bond": "C-C",
          "functionalGroup": "C-C-C skeletal stretch"
        }
      ],
      "uvVisMax": "279 nm (in water, n -> π* transition with low extinction coefficient ε = 15 M⁻¹cm⁻¹)",
      "nmr1H": "δ 2.17 (s, 6H, 2x CH3)",
      "nmr13C": "δ 30.7 (2x CH3), 206.3 (C=O carbonyl)"
    },
    "practicalApplications": [
      "Universal cleaning and glassware-drying solvent in laboratories",
      "Cosmetic nail polish remover and paint thinning solvent",
      "Precursor for methyl methacrylate (MMA) and bisphenol A (BPA) manufacturing"
    ],
    "atoms3D": [
      {
        "id": 0,
        "element": "C",
        "symbol": "C",
        "x": 0,
        "y": 0.28,
        "z": 0
      },
      {
        "id": 1,
        "element": "O",
        "symbol": "O",
        "x": 0,
        "y": 1.48,
        "z": 0
      },
      {
        "id": 2,
        "element": "C",
        "symbol": "C",
        "x": -1.28,
        "y": -0.55,
        "z": 0
      },
      {
        "id": 3,
        "element": "C",
        "symbol": "C",
        "x": 1.28,
        "y": -0.55,
        "z": 0
      },
      {
        "id": 4,
        "element": "H",
        "symbol": "H",
        "x": -1.35,
        "y": -1.18,
        "z": 0.88
      },
      {
        "id": 5,
        "element": "H",
        "symbol": "H",
        "x": -1.35,
        "y": -1.18,
        "z": -0.88
      },
      {
        "id": 6,
        "element": "H",
        "symbol": "H",
        "x": -2.12,
        "y": 0.15,
        "z": 0
      },
      {
        "id": 7,
        "element": "H",
        "symbol": "H",
        "x": 1.35,
        "y": -1.18,
        "z": 0.88
      },
      {
        "id": 8,
        "element": "H",
        "symbol": "H",
        "x": 1.35,
        "y": -1.18,
        "z": -0.88
      },
      {
        "id": 9,
        "element": "H",
        "symbol": "H",
        "x": 2.12,
        "y": 0.15,
        "z": 0
      }
    ],
    "bonds3D": [
      {
        "source": 0,
        "target": 1,
        "order": 2
      },
      {
        "source": 0,
        "target": 2,
        "order": 1
      },
      {
        "source": 0,
        "target": 3,
        "order": 1
      },
      {
        "source": 2,
        "target": 4,
        "order": 1
      },
      {
        "source": 2,
        "target": 5,
        "order": 1
      },
      {
        "source": 2,
        "target": 6,
        "order": 1
      },
      {
        "source": 3,
        "target": 7,
        "order": 1
      },
      {
        "source": 3,
        "target": 8,
        "order": 1
      },
      {
        "source": 3,
        "target": 9,
        "order": 1
      }
    ]
  },
  {
    "id": "benzaldehyde",
    "name": "Benzaldehyde",
    "iupacName": "Benzaldehyde",
    "formula": "C7H6O",
    "smiles": "C1=CC=C(C=C1)C=O",
    "inchiKey": "HUMVFWGZDYPZTL-UHFFFAOYSA-N",
    "casNumber": "100-52-7",
    "category": "Aromatic Aldehyde",
    "chemicalFamily": "aldehyde",
    "functionalGroups": [
      "Aldehyde (-CHO)",
      "Phenyl Ring (C6H5-)"
    ],
    "acidBaseProfile": {
      "character": "Neutral",
      "pKa": 14.9,
      "conjugateSpecies": "None (resistant to proton loss)"
    },
    "description": "The simplest aromatic aldehyde, consisting of a benzene ring substituted with a formyl group. A colorless liquid with a characteristic pleasant almond-like odor. Chief component of bitter almond oil.",
    "properties": {
      "molecularWeight": 106.12,
      "logP": 1.48,
      "tpsa": 17.1,
      "hBondDonors": 0,
      "hBondAcceptors": 1,
      "rotatableBonds": 1,
      "heavyAtomCount": 8,
      "charge": 0,
      "solubility": "6.95 mg/mL in H2O at 25°C",
      "meltingPoint": "-26 °C",
      "boilingPoint": "178.1 °C",
      "density": "1.04 g/cm³"
    },
    "lipinskiRuleOf5": {
      "passed": true,
      "violations": 0,
      "details": "Small lipophilic aromatic aldehyde. Meets all 4 Lipinski druglikeness criteria.",
      "mwPass": true,
      "logPPass": true,
      "donorsPass": true,
      "acceptorsPass": true
    },
    "pharmacology": {
      "mechanismOfAction": "Rapidly absorbed and oxidized by hepatic aldehyde dehydrogenase into benzoic acid, which is conjugated with glycine in mitochondria to form hippuric acid for excretion.",
      "targetReceptors": [
        "Olfactory receptors (OR51M1, OR2W1)",
        "Aldehyde Dehydrogenase (ALDH1A1)"
      ],
      "bioavailability": "80–90% oral/dermal absorption.",
      "halfLife": "1.5 – 3.0 hours",
      "metabolism": "Rapid oxidation to benzoic acid followed by glycine conjugation to hippuric acid.",
      "clearance": "Renal clearance (> 90% as urinary hippuric acid within 24 hours)."
    },
    "safetyAndHazards": {
      "hazardLevel": "Moderate",
      "ghsPictograms": [
        "GHS07_Harmful"
      ],
      "ghsSignalWord": "Warning",
      "hazardStatements": [
        "H302: Harmful if swallowed",
        "H315: Causes skin irritation",
        "H319: Causes serious eye irritation"
      ],
      "precautionaryMeasures": [
        "P280: Wear protective gloves and eye protection",
        "P301+P312: IF SWALLOWED: Call a poison center if unwell"
      ],
      "ppeRequired": [
        "Nitrile Gloves",
        "Safety Glasses",
        "Fume Hood"
      ],
      "disposalProtocol": "Organic solvent chemical disposal via certified high-temperature incineration."
    },
    "synthesisRoute": {
      "summary": "Industrial liquid-phase or gas-phase catalytic oxidation of toluene with air over vanadium pentoxide or cobalt catalysts; also prepared by hydrolysis of benzal chloride.",
      "greenChemistryScore": 89,
      "steps": [
        {
          "stepNumber": 1,
          "reactionName": "Catalytic Toluene Oxidation",
          "reactants": [
            "Toluene (C6H5CH3)",
            "Oxygen (O2)"
          ],
          "reagents": [
            "Cobalt(II) acetate / Manganese catalyst"
          ],
          "conditions": "160°C, 10 bar air pressure",
          "yield": "82%",
          "notes": "Controlled selective oxidation stops at aldehyde before forming benzoic acid."
        }
      ]
    },
    "spectroscopy": {
      "irPeaks": [
        {
          "wavenumber": 1700,
          "intensity": "Strong",
          "bond": "C=O",
          "functionalGroup": "Conjugated aromatic aldehyde carbonyl"
        },
        {
          "wavenumber": 2820,
          "intensity": "Medium",
          "bond": "C-H",
          "functionalGroup": "Aldehyde Fermi doublet (lower band)"
        },
        {
          "wavenumber": 2720,
          "intensity": "Medium",
          "bond": "C-H",
          "functionalGroup": "Aldehyde Fermi doublet (upper band)"
        },
        {
          "wavenumber": 1595,
          "intensity": "Medium",
          "bond": "C=C",
          "functionalGroup": "Aromatic ring stretching"
        }
      ],
      "uvVisMax": "246 nm (π -> π*, ε = 13,000 M⁻¹cm⁻¹), 280 nm (n -> π*)",
      "nmr1H": "δ 7.50 (t, 2H, meta-H), 7.62 (t, 1H, para-H), 7.88 (d, 2H, ortho-H), 10.02 (s, 1H, -CHO formyl proton)",
      "nmr13C": "δ 129.0 (2x C-meta), 129.7 (2x C-ortho), 134.5 (C-para), 136.5 (C-ipso), 192.4 (C=O aldehyde)"
    },
    "practicalApplications": [
      "Almond aroma flavoring and fragrance compounding in food and cosmetics",
      "Precursor in the synthesis of benzyl cinnamate, cinnamaldehyde, and dyes (malachite green)",
      "Precursor to mandelic acid and chloramphenicol antibiotic intermediate"
    ],
    "atoms3D": [
      {
        "id": 0,
        "element": "C",
        "symbol": "C",
        "x": -1.35,
        "y": 0,
        "z": 0
      },
      {
        "id": 1,
        "element": "C",
        "symbol": "C",
        "x": -0.65,
        "y": 1.21,
        "z": 0
      },
      {
        "id": 2,
        "element": "C",
        "symbol": "C",
        "x": 0.75,
        "y": 1.21,
        "z": 0
      },
      {
        "id": 3,
        "element": "C",
        "symbol": "C",
        "x": 1.45,
        "y": 0,
        "z": 0
      },
      {
        "id": 4,
        "element": "C",
        "symbol": "C",
        "x": 0.75,
        "y": -1.21,
        "z": 0
      },
      {
        "id": 5,
        "element": "C",
        "symbol": "C",
        "x": -0.65,
        "y": -1.21,
        "z": 0
      },
      {
        "id": 6,
        "element": "C",
        "symbol": "C",
        "x": 2.95,
        "y": 0,
        "z": 0
      },
      {
        "id": 7,
        "element": "O",
        "symbol": "O",
        "x": 3.65,
        "y": 1.05,
        "z": 0
      },
      {
        "id": 8,
        "element": "H",
        "symbol": "H",
        "x": 3.45,
        "y": -0.98,
        "z": 0
      },
      {
        "id": 9,
        "element": "H",
        "symbol": "H",
        "x": -2.44,
        "y": 0,
        "z": 0
      },
      {
        "id": 10,
        "element": "H",
        "symbol": "H",
        "x": -1.2,
        "y": 2.15,
        "z": 0
      },
      {
        "id": 11,
        "element": "H",
        "symbol": "H",
        "x": 1.3,
        "y": 2.15,
        "z": 0
      },
      {
        "id": 12,
        "element": "H",
        "symbol": "H",
        "x": 1.3,
        "y": -2.15,
        "z": 0
      },
      {
        "id": 13,
        "element": "H",
        "symbol": "H",
        "x": -1.2,
        "y": -2.15,
        "z": 0
      }
    ],
    "bonds3D": [
      {
        "source": 0,
        "target": 1,
        "order": 2
      },
      {
        "source": 1,
        "target": 2,
        "order": 1
      },
      {
        "source": 2,
        "target": 3,
        "order": 2
      },
      {
        "source": 3,
        "target": 4,
        "order": 1
      },
      {
        "source": 4,
        "target": 5,
        "order": 2
      },
      {
        "source": 5,
        "target": 0,
        "order": 1
      },
      {
        "source": 3,
        "target": 6,
        "order": 1
      },
      {
        "source": 6,
        "target": 7,
        "order": 2
      },
      {
        "source": 6,
        "target": 8,
        "order": 1
      },
      {
        "source": 0,
        "target": 9,
        "order": 1
      },
      {
        "source": 1,
        "target": 10,
        "order": 1
      },
      {
        "source": 2,
        "target": 11,
        "order": 1
      },
      {
        "source": 4,
        "target": 12,
        "order": 1
      },
      {
        "source": 5,
        "target": 13,
        "order": 1
      }
    ]
  }
];
