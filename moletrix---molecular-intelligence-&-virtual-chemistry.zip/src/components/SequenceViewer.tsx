import React, { useState } from 'react';
import { ProteinStructure, Residue } from '../types/protein';
import { Check, Copy, Download, FileText, Layers } from 'lucide-react';

interface SequenceViewerProps {
  structure: ProteinStructure;
  selectedResidueIndex: number | null;
  onSelectResidue: (index: number | null) => void;
}

export const SequenceViewer: React.FC<SequenceViewerProps> = ({
  structure,
  selectedResidueIndex,
  onSelectResidue,
}) => {
  const [copied, setCopied] = useState(false);

  const handleCopyFasta = () => {
    const fasta = `>${structure.id || 'protein'}|${structure.name}|${structure.uniprotId || 'Moletrix'}\n${structure.sequence}`;
    navigator.clipboard.writeText(fasta);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const getSecondaryColor = (ss: string) => {
    if (ss === 'helix') return 'bg-purple-900/60 text-purple-300 border-purple-700/60';
    if (ss === 'sheet') return 'bg-teal-900/60 text-teal-300 border-teal-700/60';
    return 'bg-slate-800/60 text-slate-400 border-slate-700/50';
  };

  return (
    <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-4 shadow-xl">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <FileText className="w-4 h-4 text-cyan-400" />
          <h3 className="text-sm font-semibold text-slate-100">Primary Sequence & Residue Topology</h3>
          <span className="text-xs text-slate-400">({structure.sequence.length} Amino Acids)</span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopyFasta}
            className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700 transition cursor-pointer"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
            <span>{copied ? 'Copied FASTA' : 'Copy FASTA'}</span>
          </button>
        </div>
      </div>

      {/* Secondary Structure Proportion Bar */}
      <div className="pt-3 pb-3">
        <div className="flex items-center justify-between text-xs text-slate-400 pb-1.5">
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded bg-purple-500 inline-block"></span>
            <span>Alpha Helix: <strong className="text-purple-300">{structure.properties.helixPercent}%</strong></span>
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded bg-teal-500 inline-block"></span>
            <span>Beta Sheet: <strong className="text-teal-300">{structure.properties.sheetPercent}%</strong></span>
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded bg-slate-500 inline-block"></span>
            <span>Turn / Loop: <strong className="text-slate-300">{structure.properties.loopPercent}%</strong></span>
          </span>
        </div>
        <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden flex">
          <div style={{ width: `${structure.properties.helixPercent}%` }} className="bg-purple-500 h-full"></div>
          <div style={{ width: `${structure.properties.sheetPercent}%` }} className="bg-teal-500 h-full"></div>
          <div style={{ width: `${structure.properties.loopPercent}%` }} className="bg-slate-600 h-full"></div>
        </div>
      </div>

      {/* Interactive Residue Stream */}
      <div className="max-h-36 overflow-y-auto pr-1 space-y-1.5 font-mono text-xs custom-scrollbar">
        <div className="flex flex-wrap gap-1">
          {structure.residues.map((res) => {
            const isSelected = selectedResidueIndex === res.index;
            return (
              <button
                key={res.index}
                onClick={() => onSelectResidue(isSelected ? null : res.index)}
                className={`group relative px-1.5 py-1 rounded-md border text-center transition cursor-pointer ${
                  isSelected
                    ? 'ring-2 ring-cyan-400 bg-cyan-600 text-white font-bold border-cyan-300 scale-105 z-10'
                    : getSecondaryColor(res.secondaryStructure)
                } ${res.isBindingSite ? 'ring-1 ring-emerald-400' : ''}`}
                title={`Residue ${res.index}: ${res.name} (${res.code3}) | 2°: ${res.secondaryStructure} | pLDDT: ${res.plddt}%`}
              >
                <div className="text-[9px] text-slate-400 group-hover:text-slate-200">
                  {res.index % 5 === 0 || res.index === 1 ? res.index : '·'}
                </div>
                <div className="font-bold text-xs">{res.code1}</div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
