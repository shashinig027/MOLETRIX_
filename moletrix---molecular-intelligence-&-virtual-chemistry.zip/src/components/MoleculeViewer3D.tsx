import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { Atom3D, Bond3D, SmallMolecule } from '../data/sampleMolecules';
import { Camera, Layers, Pause, Play, RotateCcw, Sparkles } from 'lucide-react';

interface MoleculeViewer3DProps {
  molecule: SmallMolecule;
}

// CPK Elemental Colors
const CPK_COLORS: Record<string, number> = {
  H: 0xf8fafc,
  C: 0x334155,
  N: 0x2563eb,
  O: 0xdc2626,
  S: 0xfacc15,
  P: 0xf97316,
  F: 0x22c55e,
  CL: 0x16a34a,
  BR: 0x991b1b,
  I: 0x7c3aed,
};

// VdW Radii (Å)
const VDW_RADII: Record<string, number> = {
  H: 0.35,
  C: 0.7,
  N: 0.65,
  O: 0.6,
  S: 0.9,
  P: 0.85,
  F: 0.55,
  CL: 0.75,
  BR: 0.85,
};

export const MoleculeViewer3D: React.FC<MoleculeViewer3DProps> = ({ molecule }) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const groupRef = useRef<THREE.Group | null>(null);

  const [style, setStyle] = useState<'ball_stick' | 'space_fill' | 'wireframe'>('ball_stick');
  const [isRotating, setIsRotating] = useState(true);
  const [hoveredAtom, setHoveredAtom] = useState<Atom3D | null>(null);

  const buildMolecule = () => {
    if (!groupRef.current || !molecule) return;
    const group = groupRef.current;

    while (group.children.length > 0) {
      const child = group.children[0];
      group.remove(child);
      if ((child as any).geometry) (child as any).geometry.dispose();
      if ((child as any).material) {
        if (Array.isArray((child as any).material)) {
          (child as any).material.forEach((m: any) => m.dispose());
        } else {
          (child as any).material.dispose();
        }
      }
    }

    const atoms = molecule.atoms3D || [];
    const bonds = molecule.bonds3D || [];

    // Recenter
    let sumX = 0, sumY = 0, sumZ = 0;
    atoms.forEach((a) => {
      sumX += a.x;
      sumY += a.y;
      sumZ += a.z;
    });
    const avgX = atoms.length ? sumX / atoms.length : 0;
    const avgY = atoms.length ? sumY / atoms.length : 0;
    const avgZ = atoms.length ? sumZ / atoms.length : 0;

    // 1. Atoms
    atoms.forEach((atom) => {
      const sym = atom.symbol.toUpperCase();
      const color = CPK_COLORS[sym] || 0xa855f7;
      const baseRadius = VDW_RADII[sym] || 0.6;
      const radius = style === 'space_fill' ? baseRadius * 1.8 : baseRadius * 0.75;

      const geom = new THREE.SphereGeometry(radius, 20, 20);
      const mat = new THREE.MeshStandardMaterial({
        color,
        roughness: 0.25,
        metalness: 0.15,
        wireframe: style === 'wireframe',
      });
      const mesh = new THREE.Mesh(geom, mat);
      mesh.position.set(atom.x - avgX, atom.y - avgY, atom.z - avgZ);
      mesh.castShadow = true;
      (mesh as any).userData = { atom };
      group.add(mesh);
    });

    // 2. Bonds
    if (style !== 'space_fill') {
      bonds.forEach((bond) => {
        const a1 = atoms[bond.source];
        const a2 = atoms[bond.target];
        if (!a1 || !a2) return;

        const p1 = new THREE.Vector3(a1.x - avgX, a1.y - avgY, a1.z - avgZ);
        const p2 = new THREE.Vector3(a2.x - avgX, a2.y - avgY, a2.z - avgZ);
        const dist = p1.distanceTo(p2);

        const radius = bond.order === 2 ? 0.14 : bond.order === 3 ? 0.18 : 0.11;
        const geom = new THREE.CylinderGeometry(radius, radius, dist, 12);
        geom.translate(0, dist / 2, 0);
        geom.rotateX(Math.PI / 2);

        const mat = new THREE.MeshStandardMaterial({
          color: 0x94a3b8,
          roughness: 0.4,
          metalness: 0.1,
        });
        const mesh = new THREE.Mesh(geom, mat);
        mesh.position.copy(p1);
        mesh.lookAt(p2);
        group.add(mesh);
      });
    }
  };

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const width = container.clientWidth || 700;
    const height = container.clientHeight || 450;

    const scene = new THREE.Scene();
    sceneRef.current = scene;
    scene.background = new THREE.Color(0x0a0f1d);

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.set(0, 0, 18);
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    rendererRef.current = renderer;

    container.replaceChildren(renderer.domElement);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controlsRef.current = controls;

    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    scene.add(ambientLight);

    const keyLight = new THREE.DirectionalLight(0xffffff, 1.2);
    keyLight.position.set(20, 25, 20);
    scene.add(keyLight);

    const fillLight = new THREE.DirectionalLight(0x38bdf8, 0.6);
    fillLight.position.set(-20, -10, -20);
    scene.add(fillLight);

    const group = new THREE.Group();
    scene.add(group);
    groupRef.current = group;

    let animId = 0;
    const animate = () => {
      animId = requestAnimationFrame(animate);
      if (isRotating && groupRef.current) {
        groupRef.current.rotation.y += 0.005;
      }
      controls.update();
      renderer.render(scene, camera);
    };
    animate();

    const handleResize = () => {
      if (!container || !renderer || !camera) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
    };
  }, []);

  useEffect(() => {
    buildMolecule();
  }, [molecule, style]);

  const handleSnapshot = () => {
    if (!rendererRef.current) return;
    const a = document.createElement('a');
    a.href = rendererRef.current.domElement.toDataURL('image/png');
    a.download = `${molecule.id}_3d.png`;
    a.click();
  };

  return (
    <div className="relative w-full h-[520px] bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden shadow-2xl flex flex-col">
      {/* Top Header */}
      <div className="absolute top-4 left-4 z-10 flex flex-wrap items-center gap-2">
        <div className="bg-slate-900/90 backdrop-blur-md px-3.5 py-1.5 rounded-xl border border-slate-700 shadow-lg flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-blue-400"></span>
          <span className="text-xs font-bold text-slate-100">{molecule.name}</span>
          <span className="text-[11px] font-mono text-cyan-300">({molecule.formula})</span>
        </div>
        <div className="bg-slate-900/90 backdrop-blur-md px-3 py-1.5 rounded-xl border border-slate-700 shadow-lg text-[11px] text-slate-300">
          MW: <strong className="text-slate-100">{molecule.properties.molecularWeight} g/mol</strong>
        </div>
      </div>

      <div className="absolute top-4 right-4 z-10 flex items-center gap-2">
        <button
          onClick={handleSnapshot}
          className="bg-slate-900/90 hover:bg-slate-800 text-slate-200 p-2 rounded-xl border border-slate-700 transition shadow-lg flex items-center gap-1.5 text-xs font-medium cursor-pointer"
        >
          <Camera className="w-4 h-4 text-cyan-400" />
          <span>Snapshot</span>
        </button>
      </div>

      {/* 3D Canvas */}
      <div ref={mountRef} className="w-full h-full cursor-grab active:cursor-grabbing" />

      {/* Bottom Controls */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-20 pointer-events-auto bg-slate-900/90 backdrop-blur-md px-4 py-2 rounded-2xl border border-slate-700/80 shadow-2xl flex items-center gap-3 text-xs">
        <div className="flex items-center gap-1 bg-slate-950/80 p-1 rounded-xl border border-slate-800">
          {(['ball_stick', 'space_fill', 'wireframe'] as const).map((m) => (
            <button
              key={m}
              onClick={() => setStyle(m)}
              className={`px-2.5 py-1 rounded-lg capitalize font-medium transition cursor-pointer ${
                style === m ? 'bg-cyan-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {m.replace('_', ' ')}
            </button>
          ))}
        </div>

        <button
          onClick={() => setIsRotating(!isRotating)}
          className={`p-1.5 rounded-xl border transition cursor-pointer ${
            isRotating ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50' : 'bg-slate-800 text-slate-400 border-slate-700'
          }`}
        >
          {isRotating ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
        </button>
      </div>
    </div>
  );
};
