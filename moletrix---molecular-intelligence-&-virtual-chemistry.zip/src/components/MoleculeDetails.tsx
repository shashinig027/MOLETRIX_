import React, { useState } from 'react';
import { SmallMolecule } from '../data/sampleMolecules';
import { Activity, AlertTriangle, CheckCircle, Dna, FileText, FlaskConical, Layers, ShieldCheck, Sparkles } from 'lucide-react';

interface MoleculeDetailsProps {
  molecule: SmallMolecule;
}

export const MoleculeDetails: React.FC<MoleculeDetailsProps> = ({ molecule }) => {
  const [activeTab, setActiveTab] = useState<'properties' | 'pharmacology' | 'synthesis' | 'spectroscopy' | 'safety'>('properties');
  const p = molecule.properties;
  const lip = molecule.lipinskiRuleOf5;

  return (
    <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-5 shadow-xl space-y-4">
      {/* Tab Switcher */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <FlaskConical className="w-5 h-5 text-cyan-400" />
          <h3 className="text-base font-bold text-slate-100">{molecule.name} — Chemical Intelligence</h3>
        </div>

        <div className="flex flex-wrap items-center gap-1 bg-slate-950/80 p-1 rounded-xl border border-slate-800 text-xs">
          {[
            { id: 'properties', label: 'Properties & Lipinski' },
            { id: 'pharmacology', label: 'Pharmacology & ADMET' },
            { id: 'synthesis', label: 'Retrosynthesis' },
            { id: 'spectroscopy', label: 'Spectroscopy' },
            { id: 'safety', label: 'Safety & GHS' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-3 py-1 rounded-lg font-medium transition cursor-pointer ${
                activeTab === tab.id
                  ? 'bg-cyan-600 text-white font-bold shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* TAB 1: Properties & Lipinski */}
      {activeTab === 'properties' && (
        <div className="space-y-4">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800">
              <span className="text-[11px] text-slate-400 block">Molecular Weight</span>
              <strong className="text-lg text-slate-100">{p.molecularWeight} g/mol</strong>
            </div>
            <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800">
              <span className="text-[11px] text-slate-400 block">LogP (Lipophilicity)</span>
              <strong className="text-lg text-cyan-300">{p.logP}</strong>
            </div>
            <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800">
              <span className="text-[11px] text-slate-400 block">Polar Surface Area (TPSA)</span>
              <strong className="text-lg text-slate-100">{p.tpsa} Å²</strong>
            </div>
            <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800">
              <span className="text-[11px] text-slate-400 block">H-Donors / Acceptors</span>
              <strong className="text-lg text-slate-100">{p.hBondDonors} / {p.hBondAcceptors}</strong>
            </div>
          </div>

          {/* Lipinski Rule of 5 Card */}
          <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span className="font-bold text-slate-200 text-xs">Lipinski Rule of 5 (Oral Druggability)</span>
              </div>
              <span className={`text-[10px] px-2 py-0.5 rounded font-bold uppercase ${lip.passed ? 'bg-emerald-950 text-emerald-300 border border-emerald-700' : 'bg-amber-950 text-amber-300 border border-amber-700'}`}>
                {lip.passed ? 'Compliant' : `${lip.violations} Violations`}
              </span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">{lip.details}</p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 text-[11px]">
              <div className={`p-2 rounded border ${lip.mwPass ? 'bg-emerald-950/30 border-emerald-800/40 text-emerald-300' : 'bg-red-950/30 border-red-800/40 text-red-300'}`}>
                MW &lt; 500 Da ({p.molecularWeight})
              </div>
              <div className={`p-2 rounded border ${lip.logPPass ? 'bg-emerald-950/30 border-emerald-800/40 text-emerald-300' : 'bg-red-950/30 border-red-800/40 text-red-300'}`}>
                LogP &lt; 5 ({p.logP})
              </div>
              <div className={`p-2 rounded border ${lip.donorsPass ? 'bg-emerald-950/30 border-emerald-800/40 text-emerald-300' : 'bg-red-950/30 border-red-800/40 text-red-300'}`}>
                H-Donors ≤ 5 ({p.hBondDonors})
              </div>
              <div className={`p-2 rounded border ${lip.acceptorsPass ? 'bg-emerald-950/30 border-emerald-800/40 text-emerald-300' : 'bg-red-950/30 border-red-800/40 text-red-300'}`}>
                H-Acceptors ≤ 10 ({p.hBondAcceptors})
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: Pharmacology & ADMET */}
      {activeTab === 'pharmacology' && (
        <div className="space-y-3 text-xs">
          <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800 space-y-1.5">
            <span className="font-bold text-cyan-300 block">Biochemical Mechanism of Action:</span>
            <p className="text-slate-300 leading-relaxed">{molecule.pharmacology.mechanismOfAction}</p>
          </div>
          <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800 space-y-2">
            <span className="font-bold text-slate-200 block">Target Receptors &amp; Macromolecules:</span>
            <div className="flex flex-wrap gap-1.5">
              {molecule.pharmacology.targetReceptors.map((t, i) => (
                <span key={i} className="px-2.5 py-1 rounded bg-slate-900 border border-slate-700 text-cyan-300">
                  {t}
                </span>
              ))}
            </div>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-slate-500 block">Bioavailability:</span>
              <strong className="text-slate-200">{molecule.pharmacology.bioavailability}</strong>
            </div>
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-slate-500 block">Half-Life:</span>
              <strong className="text-slate-200">{molecule.pharmacology.halfLife}</strong>
            </div>
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-slate-500 block">Metabolism:</span>
              <strong className="text-slate-200">{molecule.pharmacology.metabolism}</strong>
            </div>
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-slate-500 block">Clearance:</span>
              <strong className="text-slate-200">{molecule.pharmacology.clearance}</strong>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: Retrosynthesis */}
      {activeTab === 'synthesis' && (
        <div className="space-y-3 text-xs">
          {molecule.synthesisRoute ? (
            <div className="space-y-3">
              <div className="flex items-center justify-between pb-1">
                <span className="font-bold text-slate-100 text-sm">Synthetic Route: {molecule.synthesisRoute.name}</span>
              </div>
              {molecule.synthesisRoute.steps.map((st) => (
                <div key={st.stepNumber} className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800 space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-cyan-300">Step {st.stepNumber}: {st.reactionName}</span>
                    <span className="text-emerald-400 font-mono font-bold">Yield: {st.yieldPercent}%</span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] text-slate-400">
                    <div>Reactants: <strong className="text-slate-200">{st.reactants.join(', ')}</strong></div>
                    <div>Reagents: <strong className="text-slate-200">{st.reagents.join(', ')}</strong></div>
                  </div>
                  <p className="text-slate-300 leading-relaxed text-[11px]">{st.mechanism}</p>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-slate-400 text-center py-6">Standard industrial synthesis documented in chemical dossier.</p>
          )}
        </div>
      )}

      {/* TAB 4: Spectroscopy */}
      {activeTab === 'spectroscopy' && (
        <div className="space-y-3 text-xs">
          {molecule.spectroscopy ? (
            <div className="space-y-3">
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                <span className="font-bold text-cyan-300 block mb-1">UV-Vis Maximum Absorbance:</span>
                <span className="text-slate-200 font-mono text-sm">{molecule.spectroscopy.uvVisMax}</span>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                <span className="font-bold text-slate-200 block">Infrared (IR) Vibrational Peaks:</span>
                <div className="overflow-x-auto">
                  <table className="w-full text-left font-mono text-[11px]">
                    <thead>
                      <tr className="border-b border-slate-800 text-slate-400">
                        <th className="py-1">Wavenumber</th>
                        <th className="py-1">Intensity</th>
                        <th className="py-1">Bond</th>
                        <th className="py-1">Assignment</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/40 text-slate-300">
                      {molecule.spectroscopy.irPeaks?.map((peak, i) => (
                        <tr key={i}>
                          <td className="py-1 font-bold text-cyan-300">{peak.wavenumber} cm⁻¹</td>
                          <td className="py-1">{peak.intensity}</td>
                          <td className="py-1 font-sans">{peak.bond}</td>
                          <td className="py-1 font-sans">{peak.assignment}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          ) : (
            <p className="text-slate-400 text-center py-6">Spectroscopic fingerprints available in analytical report.</p>
          )}
        </div>
      )}

      {/* TAB 5: Safety & GHS */}
      {activeTab === 'safety' && (
        <div className="space-y-3 text-xs">
          {molecule.safetyAndHazards ? (
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-400" />
                <span className="font-bold text-slate-200">
                  GHS Classification: <strong className="text-amber-400 uppercase">{molecule.safetyAndHazards.ghsSignalWord || 'WARNING'}</strong>
                </span>
              </div>
              <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                <span className="font-bold text-amber-300 block">Hazard Statements:</span>
                <ul className="list-disc pl-4 space-y-0.5 text-slate-300">
                  {molecule.safetyAndHazards.hazardStatements?.map((h, i) => (
                    <li key={i}>{h}</li>
                  ))}
                </ul>
              </div>
              <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                <span className="font-bold text-emerald-300 block">Recommended PPE:</span>
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {molecule.safetyAndHazards.ppeChecklist?.map((item, i) => (
                    <span key={i} className="px-2.5 py-1 rounded bg-slate-900 border border-slate-700 text-slate-200">
                      ✓ {item}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <p className="text-slate-400 text-center py-6">Standard laboratory precautions apply.</p>
          )}
        </div>
      )}
    </div>
  );
};
