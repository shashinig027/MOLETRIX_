import React, { useState } from 'react';
import { HeroGenerator, FilterCategory } from './components/HeroGenerator';
import { StructureViewer3D } from './components/StructureViewer3D';
import { SequenceViewer } from './components/SequenceViewer';
import { PropertiesPanel } from './components/PropertiesPanel';
import { MolecularIntelligenceCard } from './components/MolecularIntelligenceCard';
import { MoleculeViewer3D } from './components/MoleculeViewer3D';
import { MoleculeDetails } from './components/MoleculeDetails';
import { CompareMatrix } from './components/CompareMatrix';
import { PredictModal } from './components/PredictModal';
import { FinalReportModal } from './components/FinalReportModal';
import { BUILTIN_PROTEIN_STRUCTURES, INITIAL_COMPARE_TARGETS, PREDEFINED_PROTEINS } from './data/sampleProteins';
import { SAMPLE_MOLECULES, SmallMolecule } from './data/sampleMolecules';
import { CompareTarget, ProteinStructure } from './types/protein';
import { computeBiophysicalProperties, predictSecondaryStructureSequence, sanitizeSequence } from './utils/bioMath';
import { generateProtein3DStructure } from './utils/coordinateGenerator';
import {
  Activity,
  Atom,
  Clock,
  Dna,
  FileText,
  FlaskConical,
  GitCompare,
  Layers,
  Sparkles,
} from 'lucide-react';

export default function App() {
  // Lead Chemist Name
  const [chemistName, setChemistName] = useState('Dr. Chemist');

  // Filter Category
  const [activeFilter, setActiveFilter] = useState<FilterCategory>('smiles');

  // Active Tab
  const [activeTab, setActiveTab] = useState<'3d_viewer' | 'pharmacology' | 'retrosynthesis' | 'compare' | 'final_report'>('3d_viewer');

  // Whether a protein or small molecule is currently active
  const [isProteinActive, setIsProteinActive] = useState<boolean>(false);

  // Active Protein Target (default: Insulin)
  const [currentProtein, setCurrentProtein] = useState<ProteinStructure>(
    BUILTIN_PROTEIN_STRUCTURES['insulin-human'] || Object.values(BUILTIN_PROTEIN_STRUCTURES)[0]
  );

  // Active Small Molecule (default: Ethanol CCO, matching screenshot!)
  const defaultEthanol = SAMPLE_MOLECULES.find((m) => m.id === 'ethanol') || SAMPLE_MOLECULES[0];
  const [currentMolecule, setCurrentMolecule] = useState<SmallMolecule>(defaultEthanol);

  // Session molecules list (starts with all 16)
  const [sessionMolecules, setSessionMolecules] = useState<SmallMolecule[]>(SAMPLE_MOLECULES);

  // Selected residue in protein 3D view
  const [selectedResidueIndex, setSelectedResidueIndex] = useState<number | null>(null);

  // Compare Targets
  const [compareTargets, setCompareTargets] = useState<CompareTarget[]>(INITIAL_COMPARE_TARGETS);

  // Modals
  const [isPredictModalOpen, setIsPredictModalOpen] = useState(false);
  const [isPrintReportOpen, setIsPrintReportOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  // Generate / Search Query Handler (supports SMILES, chemical names, and protein names!)
  const handleGenerateQuery = async (query: string, reportType: string) => {
    setIsLoading(true);
    const qLower = query.trim().toLowerCase();

    try {
      // 1. Check if query matches a predefined protein
      const matchedProtein = PREDEFINED_PROTEINS.find(
        (p) =>
          p.name.toLowerCase().includes(qLower) ||
          p.id.toLowerCase().includes(qLower) ||
          p.uniprotId.toLowerCase() === qLower
      );

      if (matchedProtein || activeFilter === 'proteins' || qLower.includes('protein') || qLower.includes('insulin') || qLower.includes('gfp') || qLower.includes('spike')) {
        const pId = matchedProtein?.id || 'insulin-human';
        const struct = BUILTIN_PROTEIN_STRUCTURES[pId];
        if (struct) {
          setCurrentProtein(struct);
          setIsProteinActive(true);
          setSelectedResidueIndex(null);
          setIsLoading(false);
          return;
        }
      }

      // 2. Check if query matches any of our 16 library molecules by SMILES, formula, or name
      const matchedMol = sessionMolecules.find(
        (m) =>
          m.smiles.toLowerCase() === qLower ||
          m.formula.toLowerCase() === qLower ||
          m.name.toLowerCase().includes(qLower) ||
          m.id.toLowerCase() === qLower
      );

      if (matchedMol) {
        setCurrentMolecule(matchedMol);
        setIsProteinActive(false);
        setIsLoading(false);
        return;
      }

      // 3. Query server /api/molecules/generate for de novo SMILES synthesis
      try {
        const response = await fetch('/api/molecules/generate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ query, focusArea: reportType, userName: chemistName }),
        });
        const res = await response.json();
        if (res.molecule) {
          setSessionMolecules((prev) => [res.molecule, ...prev]);
          setCurrentMolecule(res.molecule);
          setIsProteinActive(false);
          setIsLoading(false);
          return;
        }
      } catch (err) {
        console.warn('Backend generation fallback to closest match:', err);
      }

      // Fallback: switch to first molecule
      setCurrentMolecule(sessionMolecules[0]);
      setIsProteinActive(false);
    } finally {
      setIsLoading(false);
    }
  };

  // Add Current to Compare
  const handleAddCurrentToCompare = () => {
    if (isProteinActive) {
      if (compareTargets.some((t) => t.id === currentProtein.id)) return;
      setCompareTargets([
        ...compareTargets,
        {
          id: currentProtein.id,
          name: currentProtein.name,
          badge: currentProtein.organism || 'Predicted',
          sequence: currentProtein.sequence,
          properties: currentProtein.properties,
          keyActiveSite: currentProtein.pockets?.[0]?.name || 'Primary Binding Surface',
          isBaseline: false,
        },
      ]);
    } else {
      // Add molecule as compare target
      if (compareTargets.some((t) => t.id === currentMolecule.id)) return;
      const molSec = predictSecondaryStructureSequence('ACDEFGHIKLMNPQRSTVWY');
      const molProps = computeBiophysicalProperties('ACDEFGHIKLMNPQRSTVWY', molSec);
      molProps.molecularWeightKDa = Number((currentMolecule.properties.molecularWeight / 1000).toFixed(2));
      molProps.solubilityScore = currentMolecule.properties.logP < 2 ? 88 : 55;

      setCompareTargets([
        ...compareTargets,
        {
          id: currentMolecule.id,
          name: currentMolecule.name,
          badge: currentMolecule.formula,
          sequence: currentMolecule.smiles,
          properties: molProps,
          keyActiveSite: currentMolecule.pharmacology.targetReceptors[0] || 'Target Macromolecule',
          therapeuticCategory: currentMolecule.category,
          isBaseline: false,
        },
      ]);
    }
  };

  const handleSelectFilter = (filter: FilterCategory) => {
    setActiveFilter(filter);
    if (filter === 'proteins') {
      setIsProteinActive(true);
    } else if (filter === 'alcohols') {
      const eth = sessionMolecules.find((m) => m.id === 'ethanol');
      if (eth) {
        setCurrentMolecule(eth);
        setIsProteinActive(false);
      }
    } else if (filter === 'acids') {
      const ac = sessionMolecules.find((m) => m.id === 'acetic_acid');
      if (ac) {
        setCurrentMolecule(ac);
        setIsProteinActive(false);
      }
    } else if (filter === 'bases') {
      const py = sessionMolecules.find((m) => m.id === 'pyridine');
      if (py) {
        setCurrentMolecule(py);
        setIsProteinActive(false);
      }
    } else {
      setIsProteinActive(false);
    }
  };

  // Predict from Custom Sequence
  const handlePredictCustom = async (name: string, sequence: string) => {
    setIsLoading(true);
    try {
      const sec = predictSecondaryStructureSequence(sequence);
      const props = computeBiophysicalProperties(sequence, sec);
      const newStructure = generateProtein3DStructure(
        `custom-${Date.now()}`,
        name,
        sequence,
        sec,
        props,
        'De novo computed molecular structure and biophysical characterization.'
      );

      try {
        const response = await fetch('/api/predict-protein', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name, sequence }),
        });
        const res = await response.json();
        if (res.data?.aiInsights) {
          newStructure.aiInsights = res.data.aiInsights;
        }
      } catch (e) {}

      setCurrentProtein(newStructure);
      setIsProteinActive(true);
      setSelectedResidueIndex(null);
    } finally {
      setIsLoading(false);
    }
  };

  const handlePredictWithAi = async (query: string) => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/predict-protein', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query }),
      });
      const res = await response.json();
      let targetSeq = res.data?.standardSequence || 'GIVEQCCTSICSLYQLENYCNFVNQHLCGSHLVEALYLVCGERGFFYTPKT';
      const sec = predictSecondaryStructureSequence(targetSeq);
      const props = computeBiophysicalProperties(targetSeq, sec);
      const newStructure = generateProtein3DStructure(
        `ai-${Date.now()}`,
        res.data?.name || query,
        targetSeq,
        sec,
        props,
        res.data?.description || 'AI Synthesized Target'
      );
      newStructure.aiInsights = res.data?.aiInsights;
      setCurrentProtein(newStructure);
      setIsProteinActive(true);
      setSelectedResidueIndex(null);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="relative min-h-screen text-slate-100 selection:bg-cyan-500 selection:text-black">
      {/* Exact Molecular Laboratory Background from Screenshot */}
      <div
        className="fixed inset-0 pointer-events-none z-0 bg-cover bg-center bg-no-repeat transition-opacity duration-700 ease-out"
        style={{
          backgroundImage: 'url(/assets/molecular_background.jpg)',
          opacity: 0.62,
        }}
      />
      {/* Vignette Layer */}
      <div className="fixed inset-0 pointer-events-none z-0 bg-gradient-to-b from-slate-950/75 via-slate-950/85 to-slate-950" />

      {/* Main Content Container */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 py-4 space-y-6">
        {/* Top Header & Hero Generator matching Screenshot */}
        <HeroGenerator
          chemistName={chemistName}
          onChangeChemistName={setChemistName}
          onOpenReport={() => setIsPrintReportOpen(true)}
          activeFilter={activeFilter}
          onSelectFilter={handleSelectFilter}
          onGenerateQuery={handleGenerateQuery}
          isLoading={isLoading}
          activeMolecule={currentMolecule}
          activeProtein={currentProtein}
          onSelectSessionMolecule={(id) => {
            const m = sessionMolecules.find((x) => x.id === id);
            if (m) {
              setCurrentMolecule(m);
              setIsProteinActive(false);
            }
          }}
          sessionMolecules={sessionMolecules}
          isProteinActive={isProteinActive}
        />

        {/* Main Tab Navigation Buttons */}
        <div className="flex flex-wrap items-center justify-between gap-3 p-1.5 rounded-2xl bg-slate-900/80 border border-slate-700/80 backdrop-blur-md shadow-xl text-xs font-mono">
          <div className="flex flex-wrap items-center gap-1.5">
            <button
              onClick={() => setActiveTab('3d_viewer')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl font-semibold transition cursor-pointer ${
                activeTab === '3d_viewer'
                  ? 'bg-gradient-to-r from-cyan-500/30 to-blue-500/30 text-cyan-300 border border-cyan-400/50 shadow-md shadow-cyan-950/40'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <Layers className="w-4 h-4 text-cyan-400" />
              <span>3D Molecular Lab</span>
            </button>

            <button
              onClick={() => setActiveTab('pharmacology')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl font-semibold transition cursor-pointer ${
                activeTab === 'pharmacology'
                  ? 'bg-gradient-to-r from-cyan-500/30 to-blue-500/30 text-cyan-300 border border-cyan-400/50 shadow-md shadow-cyan-950/40'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <Activity className="w-4 h-4 text-blue-400" />
              <span>Pharmacology &amp; ADMET</span>
            </button>

            <button
              onClick={() => setActiveTab('retrosynthesis')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl font-semibold transition cursor-pointer ${
                activeTab === 'retrosynthesis'
                  ? 'bg-gradient-to-r from-cyan-500/30 to-blue-500/30 text-cyan-300 border border-cyan-400/50 shadow-md shadow-cyan-950/40'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <FlaskConical className="w-4 h-4 text-emerald-400" />
              <span>Retrosynthesis Pathways</span>
            </button>

            <button
              onClick={() => setActiveTab('compare')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl font-semibold transition cursor-pointer ${
                activeTab === 'compare'
                  ? 'bg-gradient-to-r from-cyan-500/30 to-blue-500/30 text-cyan-300 border border-cyan-400/50 shadow-md shadow-cyan-950/40'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <GitCompare className="w-4 h-4 text-purple-400" />
              <span>Compare Matrix</span>
              <span className="w-4 h-4 rounded-full bg-purple-900 text-purple-300 text-[10px] flex items-center justify-center font-bold">
                {compareTargets.length}
              </span>
            </button>
          </div>

          <button
            onClick={() => setIsPrintReportOpen(true)}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold transition shadow-lg shadow-cyan-900/30 cursor-pointer"
          >
            <FileText className="w-4 h-4" />
            <span>Overall Final Report</span>
          </button>
        </div>

        {/* View Content depending on active tab & mode */}
        {activeTab === '3d_viewer' && (
          <div className="space-y-6">
            {isProteinActive ? (
              <>
                <div className="space-y-2">
                  <StructureViewer3D
                    structure={currentProtein}
                    selectedResidueIndex={selectedResidueIndex}
                    onSelectResidue={setSelectedResidueIndex}
                  />
                </div>
                <SequenceViewer
                  structure={currentProtein}
                  selectedResidueIndex={selectedResidueIndex}
                  onSelectResidue={setSelectedResidueIndex}
                />
                <PropertiesPanel
                  structure={currentProtein}
                  selectedResidueIndex={selectedResidueIndex}
                  onSelectResidue={setSelectedResidueIndex}
                />
                <MolecularIntelligenceCard structure={currentProtein} />
              </>
            ) : (
              <>
                <MoleculeViewer3D molecule={currentMolecule} />
                <MoleculeDetails molecule={currentMolecule} />
              </>
            )}
          </div>
        )}

        {activeTab === 'pharmacology' && (
          <div className="space-y-4">
            {isProteinActive ? (
              <PropertiesPanel
                structure={currentProtein}
                selectedResidueIndex={selectedResidueIndex}
                onSelectResidue={setSelectedResidueIndex}
              />
            ) : (
              <MoleculeDetails molecule={currentMolecule} />
            )}
          </div>
        )}

        {activeTab === 'retrosynthesis' && (
          <div className="space-y-4">
            {isProteinActive ? (
              <MolecularIntelligenceCard structure={currentProtein} />
            ) : (
              <MoleculeDetails molecule={currentMolecule} />
            )}
          </div>
        )}

        {activeTab === 'compare' && (
          <div className="space-y-4">
            <CompareMatrix
              targets={compareTargets}
              currentStructure={currentProtein}
              onAddCurrentToCompare={handleAddCurrentToCompare}
              onRemoveTarget={(id) => setCompareTargets(compareTargets.filter((t) => t.id !== id))}
              onSetBaseline={(id) =>
                setCompareTargets(
                  compareTargets.map((t) => ({
                    ...t,
                    isBaseline: t.id === id,
                  }))
                )
              }
              onOpenPrintReport={() => setIsPrintReportOpen(true)}
            />
          </div>
        )}

        {/* Always present Compare Matrix Section below for direct accessibility */}
        {activeTab !== 'compare' && (
          <div className="pt-6">
            <CompareMatrix
              targets={compareTargets}
              currentStructure={currentProtein}
              onAddCurrentToCompare={handleAddCurrentToCompare}
              onRemoveTarget={(id) => setCompareTargets(compareTargets.filter((t) => t.id !== id))}
              onSetBaseline={(id) =>
                setCompareTargets(
                  compareTargets.map((t) => ({
                    ...t,
                    isBaseline: t.id === id,
                  }))
                )
              }
              onOpenPrintReport={() => setIsPrintReportOpen(true)}
            />
          </div>
        )}
      </div>

      {/* Predict Modal */}
      <PredictModal
        isOpen={isPredictModalOpen}
        onClose={() => setIsPredictModalOpen(false)}
        onSelectPredefined={(id) => {
          const struct = BUILTIN_PROTEIN_STRUCTURES[id];
          if (struct) {
            setCurrentProtein(struct);
            setIsProteinActive(true);
            setSelectedResidueIndex(null);
          }
        }}
        onPredictCustom={handlePredictCustom}
        onPredictWithAi={handlePredictWithAi}
        isLoading={isLoading}
      />

      {/* Printable Final Report Dossier with Compare Matrix explicitly included */}
      <FinalReportModal
        isOpen={isPrintReportOpen}
        onClose={() => setIsPrintReportOpen(false)}
        structure={currentProtein}
        compareTargets={compareTargets}
      />
    </div>
  );
}
